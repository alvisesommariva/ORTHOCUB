
function [m,m0,map]=mom_derivative_3D(x,y,z,a1,a2,a3,deg,basis_indices,...
    dbox)

%--------------------------------------------------------------------------
% Object.
%--------------------------------------------------------------------------
% This routine computes the derivative of the orthonormal tensorial 
% Chebyshev basis 
%
%                     c_{hkl} * T_h(x) T_k(y) T_l(z)
%
% at the point "(x,y,z)", varying "h", "k", "l" so that "0 <= h+k+l<=deg".
% 
% The order of the derivative is 
% 
% * "a1" in the direction "x", 
% * "a2" in the direction "y".
% * "a3" in the direction "z".
%
% The variable "basis_indices" is an (deg+1)(deg+2)(deg+3) x 6 matrix of 
% indices (h,k,l) that order the elements of the polynomial basis.
%
% The variable "dbox" defines a rectangle [a,b] x [c,d] x [e,f] as matrix
% [a c e; b d f], typically including the point "(x,y,z)".
% 
% The output consistes of the vector "m" of these derivatives as well as 
% the vector "m0" introduced in reference [1], that is essentially a
% scaling of "m".
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% [1] "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      moments", 2025.
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) Core(TM) Ultra 5 125H
% 3.60 GHz with 16 GB of RAM.
%--------------------------------------------------------------------------
% External routines.
%--------------------------------------------------------------------------
% 1. vandermonde_jacobi
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 14, 2025
%--------------------------------------------------------------------------

if nargin < 6, dbox=[-1 -1 -1; 1 1 1]; end

% The variable "d=3" specifies that a trivariate problem is considered.
d=3;

% box factors
a=dbox(1,:); b=dbox(2,:);

% map points to [-1,1] x [-1,1]
X=[x y z];
map = zeros(size(X));
for i=1:d
    map(:,i)=(2*X(:,i)-b(i)-a(i))/(b(i)-a(i));
end
x_ref= map(:,1);
y_ref= map(:,2);
z_ref= map(:,3);

% Defining Vandermonde matrices useful in the calculation of the
% derivatives.

Vx=vandermonde_jacobi(deg,x_ref,a1-1/2,a1-1/2,'trad');
Vy=vandermonde_jacobi(deg,y_ref,a2-1/2,a2-1/2,'trad');
Vz=vandermonde_jacobi(deg,z_ref,a3-1/2,a3-1/2,'trad');

% Adding a null column (it is fundamental for differentiation of 
% polynomials of degree "0".

Vx=[zeros(size(x_ref)) Vx];
Vy=[zeros(size(y_ref)) Vy];
Vz=[zeros(size(z_ref)) Vz];

% Computation of vector of differential moments "m0".

m0=zeros(length(x), size(basis_indices,1));

for ii=1:size(basis_indices,1)
    h=basis_indices(ii,1); k=basis_indices(ii,2); l=basis_indices(ii,3);
    scaling_term=sqrt(2-(h == 0))*sqrt(2-(k == 0))*sqrt(2-(l == 0))/...
        2^(a1+a2+a3);
    term(1)=pochhammerM(h+1/2,1/2);
    term(2)=pochhammerM(h,a1);
    term(3)=pochhammerM(k+1/2,1/2);
    term(4)=pochhammerM(k,a2);
    term(5)=pochhammerM(l+1/2,1/2);
    term(6)=pochhammerM(l,a3);

    ix=max(h-a1+2,1);
    pol1=Vx(:,ix);
    iy=max(k-a2+2,1);
    pol2=Vy(:,iy);
    iz=max(l-a3+2,1);
    pol3=Vz(:,iz);

    m0(:,ii)=scaling_term*prod(term)*pol1.*pol2.*pol3;
end

lambdaV=(b-a)/2;
scaling_m0=prod(lambdaV.^[-a1 -a2 -a3]);
m0=scaling_m0*m0'; % Attention to composition with Lambda.

% Computation of vector of differential moments "m".
det_lambda=prod((b-a)/2);
lambda_factor=1/sqrt(det_lambda);
m=lambda_factor*m0;



function val=pochhammerM(x,n)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% This basic routine computes the Pochhammer value "(x)_n" with the
% assumption that "(0)_0=1" and "(x)_0=0" when "x" is not null.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 11, 2025
%--------------------------------------------------------------------------

if x == 0
    if n == 0
        val = 1;
    else
        val=0;
    end
else
    val=gamma(x+n)/gamma(x);
end