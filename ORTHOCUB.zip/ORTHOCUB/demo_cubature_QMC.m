
function demo_cubature_QMC

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows the quality of numerical integration of some test
% functions.
% The domain is the union of some balls and QMC rules are applied to
% determine the approximation of the moments.
%
% The routine approximates the integrals of 5 test functions, with
% different regularity, by rules with different algebraic degree of
% precision.
%--------------------------------------------------------------------------
% Important: 
%--------------------------------------------------------------------------
% The function requires the Matlab built-in function "haltonset".
% In case it is not installed, it is part of the "Statistics and Machine 
% Learning Toolbox".
%--------------------------------------------------------------------------
% Related papers:
%--------------------------------------------------------------------------
% [1] "Effective numerical integration on complex shaped elements by
%      discrete signed measures", 2025,
%      by L. Rinaldi, A. Sommariva, M. Vianello.
% [2] "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      moments", 2025,
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Examples.
%--------------------------------------------------------------------------
% >> tic; demo_cubature_QMC; toc
%
%  	 .............. Relative errors QMC Rules  ...............
%
%  	 |   f1    |    f2    |    f3    |    f4    |    f5
%  	 .........................................................
%  	   6e-04   &  7e-03   &  3e-03   &  2e-02   &  4e-03
%
%  	 .............. Relative errors Cheap Rules  .............
%  	 | ade |    f1    |    f2    |    f3   |    f4   |    f5
%  	 ..........................................................
%  	    2  &  3e-02   &  9e+01   &  9e-02 &  7e+02   &  1e+00
%  	    4  &  4e-03   &  6e+00   &  6e-03 &  3e+02   &  8e-02
%  	    6  &  5e-04   &  9e-01   &  3e-03 &  2e+01   &  7e-03
%  	    8  &  7e-04   &  7e-02   &  3e-03 &  3e+01   &  4e-03
%  	   10  &  6e-04   &  7e-03   &  2e-03 &  1e+01   &  4e-03
%  	   12  &  6e-04   &  7e-03   &  3e-03 &  6e-01   &  4e-03
%  	   14  &  6e-04   &  7e-03   &  3e-03 &  4e-01   &  4e-03
%  	   16  &  6e-04   &  7e-03   &  3e-03 &  3e-02   &  4e-03
%
%  	 ...... Relative errors Cheap vs. their QMC rule ..........
%  	 | ade |    f1    |    f2    |    f3   |    f4   |    f5
%  	 ..........................................................
%  	    2  &  3e-02   &  9e+01   &  9e-02 &  7e+02   &  1e+00
%  	    4  &  5e-03   &  6e+00   &  9e-03 &  3e+02   &  8e-02
%  	    6  &  1e-04   &  9e-01   &  7e-05 &  2e+01   &  3e-03
%  	    8  &  3e-05   &  6e-02   &  1e-04 &  3e+01   &  2e-05
%  	   10  &  2e-06   &  7e-05   &  1e-04 &  1e+01   &  2e-13
%  	   12  &  2e-07   &  7e-06   &  4e-05 &  5e-01   &  2e-13
%  	   14  &  2e-08   &  1e-06   &  5e-06 &  5e-01   &  2e-13
%  	   16  &  6e-10   &  4e-08   &  2e-06 &  1e-02   &  2e-13
%
%  	 .................. integrands ............................
%       f1: exp(-(x.^2+y.^2+z.^2))
%       f2: (x.^2+y.^2+z.^2).^(11/2)
%       f3: (x.^2+y.^2+z.^2).^(3/2)
%       f4: (0.3+0.1*x-0.2*y+0.6*z).^30
%       f5: (1.1+0.5*x-0.2*y+0.4*z).^10
%
% Elapsed time is 2.007981 seconds.
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% Cputime:
%--------------------------------------------------------------------------
% The demo requires, approximatively, 2s.
%--------------------------------------------------------------------------
% Routines.
%--------------------------------------------------------------------------
% 1. QMC_union_balls
% 2. cheap_startup
% 3. dCHEBVAND_orthn
% 4. cheap_rule
% 5. test_functions (attached below)
%
% as well as subroutines called by the functions above.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 23, 2025
%--------------------------------------------------------------------------

card_ref=10^6; % QMC cardinality (ref.results, points in bounding box).
card=10^5; % QMC cardinality (QMC in tests, points in bounding box).
adeV=2:2:16; % Degree of precision of the rule.
num_functions=5; % Polynomial tests.




% ........................ main code below ................................

isOctave = exist('OCTAVE_VERSION', 'builtin') ~= 0;

% ........................... A. define domain ............................

% Introduce centers and radii of the balls.
card_centers=5;

if isOctave
    centers =[ 0                         0                         0
        5.0e-01     3.333333333333333e-01     2.0e-01
        2.5e-01     6.666666666666666e-01     4.0e-01
        7.5e-01     1.111111111111111e-01     6.0e-01
        1.25e-01     4.444444444444444e-01     8.0e-01];
else
    p=haltonset(3);
    centers=p(1:card_centers,:);
end


radii=0.5*ones(card_centers,1);

% Compute bounding box

xmin=centers(:,1)-radii; xmax=centers(:,1)+radii;
ymin=centers(:,2)-radii; ymax=centers(:,2)+radii;
zmin=centers(:,3)-radii; zmax=centers(:,3)+radii;

dbox_X=[min(xmin) max(xmax)];
dbox_Y=[min(ymin) max(ymax)];
dbox_Z=[min(zmin) max(zmax)];

dbox=[dbox_X; dbox_Y; dbox_Z]';




% ...................... B. QMC reference pointset ........................

% QMC points reference rule
[pts_QMC_ref,w_QMC_ref]=QMC_union_balls(card_ref,centers,radii,dbox);

% QMC initial rule
[pts_QMC,w_QMC]=QMC_union_balls(card,centers,radii,dbox);




% ...................... B. QMC reference integrals .......................

XR=pts_QMC_ref(:,1); YR=pts_QMC_ref(:,2); ZR=pts_QMC_ref(:,3);

I=zeros(num_functions,1);
for example=1:num_functions
    f=test_functions(example);
    I(example)=w_QMC_ref'*f(XR,YR,ZR);
end

XQ=pts_QMC(:,1); YQ=pts_QMC(:,2); ZQ=pts_QMC(:,3);

I_QMC=zeros(num_functions,1);

for example=1:num_functions
    f=test_functions(example);
    I_QMC(example)=w_QMC'*f(XQ,YQ,ZQ);
end




%  .............. C. Compute experiments, varying degree  .................

I_ch=zeros(length(adeV),num_functions);

for ii=1:length(adeV)

    ade=adeV(ii);

    % .................... 1. QMC cheap startup ...........................

    [ruleL_ref,basis_indicesL,VL_ref]=cheap_startup(ade,3);


    % .................... 2. Compute QMC moments .........................

    V_ade_QMC = dCHEBVAND_orthn(ade,pts_QMC,dbox,basis_indicesL);
    cmom_orthnL=(w_QMC'*V_ade_QMC)';

    % .................... 3. QMC cheap rule ..............................

    XYL=cheap_rule(ruleL_ref,VL_ref,dbox);
    XL=XYL(:,1); YL=XYL(:,2); ZL=XYL(:,3);
    WL=(ruleL_ref(:,4)).*VL_ref*cmom_orthnL;


    % .................... 4. Compute integrals  ..........................
    IL=zeros(1,num_functions);
    for example=1:num_functions
        f=test_functions(example);
        IL(1,example)=WL'*feval(f,XL,YL,ZL);
    end

    % .................... 5. Storage  ....................................
    I_ch(ii,:)=IL;

    [ade length(WL)]

end




%  .......................... D. Statistics ...............................

%  ................... 1. compute relative errors .........................

RE_QMC=abs(I_QMC-I)./abs(I);

RE=zeros(length(adeV),num_functions);
for j=1:num_functions
    RE(:,j)=abs(I(j)-I_ch(:,j))./abs(I(j));
end

REc=zeros(length(adeV),num_functions);
for j=1:num_functions
    REc(:,j)=abs(I_QMC(j)-I_ch(:,j))./abs(I_QMC(j));
end


%  ................... 2. display relative errors .........................


fprintf('\n \t .............. Relative errors QMC Rules  ................')
fprintf('\n');

fprintf('\n \t |   f1    |    f2    |    f3    |    f4    |    f5     ')
fprintf('\n \t ..........................................................')

fprintf('\n \t  %1.0e   &  %1.0e   &  %1.0e   &  %1.0e   &  %1.0e   ',...
    RE_QMC(1),RE_QMC(2),RE_QMC(3),RE_QMC(4),RE_QMC(5));



fprintf('\n');
fprintf('\n \t .............. Relative errors Cheap Rules  ..............')
fprintf('\n \t | ade |    f1    |    f2    |    f3   |    f4   |    f5  ')
fprintf('\n \t ..........................................................')

for k=1:length(adeV)
    fprintf('\n \t \t');
    fprintf('%2.0f &   %1.0e   &  %1.0e   &  %1.0e &  %1.0e   &  %1.0e',...
        adeV(k),RE(k,1),RE(k,2),RE(k,3),RE(k,4),RE(k,5));
end



fprintf('\n');
fprintf('\n \t ...... Relative errors Cheap vs. their QMC rule ..........')

fprintf('\n \t | ade |    f1    |    f2    |    f3   |    f4   |    f5   ')
fprintf('\n \t ..........................................................')

for k=1:length(adeV)
    fprintf('\n \t \t');
    fprintf('%2.0f  &  %1.0e  &   %1.0e   &  %1.0e &  %1.0e   &  %1.0e',...
        adeV(k),REc(k,1),REc(k,2),REc(k,3),REc(k,4),REc(k,5));
end



fprintf('\n');
fprintf('\n \t .................. integrands ............................')
fprintf('\n');

for k=1:num_functions
    switch k
        case 1
            str=' exp(-(x.^2+y.^2+z.^2))';
        case 2
            str=' (x.^2+y.^2+z.^2).^(11/2)';
        case 3
            str=' (x.^2+y.^2+z.^2).^(3/2)';
        case 4
            str=' (0.3+0.1*x-0.2*y+0.6*z).^30';
        case 5
            str=' (1.1+0.5*x-0.2*y+0.4*z).^10';
    end

    strL=strcat('      f',num2str(k),': ',str);
    disp(strL);
end

fprintf('\n \n');






function f=test_functions(example)

switch example
    case 1
        f=@(x,y,z) exp(-(x.^2+y.^2+z.^2));
    case 2
        f=@(x,y,z) (x.^2+y.^2+z.^2).^(11/2);
    case 3
        f=@(x,y,z) (x.^2+y.^2+z.^2).^(3/2);
    case 4
        f=@(x,y,z) (0.3+0.1*x-0.2*y+0.6*z).^30;
    case 5
        f=@(x,y,z) (1.1+0.5*x-0.2*y+0.4*z).^10;
end


