
function demo_derivative_ade_2D

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% The purpose of this routine is to test the algorithm proposed in [2] for
% the computation of directional derivatives (up to second order) of
% random polynomials defined in R^2.
%
% For degree "ade" we differentiate random polynomials of degree "ade" of
% the form "(a(1)*x+a(2)*y+a(3))^ade" with the vector "a" in [0,1]^3.
%
% For each derivative we compute the maximum relative error made by the
% algorithm on the mesh of "npts".
%
% We perform "ntests" and display for each "ade" these results and its
% logarithmic average.
%--------------------------------------------------------------------------
% Important.
%--------------------------------------------------------------------------
% The routine requires the Matlab-built in function "haltonset".
% In case it is not installed, it is part of the "Statistics and Machine
% Learning Toolbox".
%--------------------------------------------------------------------------
% External routines
%--------------------------------------------------------------------------
% 1. cheap_startup
% 2. mom_derivative_2D
% 3. cheap_rule
% 4. plot_errors
% as well as the procedures potentially called by the routines above.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% [1]  "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      moments", 2025,
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> tic; demo_derivative_ade_2D; toc
%
%  	 * investigating degree 2
%  	 * investigating degree 4
%  	 * investigating degree 6
%  	 * investigating degree 8
%  	 * investigating degree 10
%  	 * investigating degree 12
%  	 * investigating degree 14
%  	 * investigating degree 16
%  	 ............................................
%
%  	 Derivatives are evaluated in   100 pts.
%  	 Number of random polynomials:   100 pts.
%  	 ............................................
%
%  	 See figures in which we describe
%  	 a) by + the norm 2 of the pointwise errors
%  	    in a cloud of random points divided by the
%  	    norm 2 of the derivatives in that cloud;
%  	 b) by a circle the logarithmic average of
%  	    the quantities above.
%
%  	 All the figures are saved in eps files.
%  	 ............................................
%
% Elapsed time is 3.005035 seconds.
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% Cputime.
%--------------------------------------------------------------------------
% The procedure requires about 3s (in case the figures are not saved).
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 23, 2025
%--------------------------------------------------------------------------

adeV=2:2:16;

% Number of points in [-1,1]^2 in which the derivatives must be computed.
npts=100;

% Number of random polynomials for which the derivatives must be computed.
ntests=100;

% Save figures: 0: no, 1: yes.
savefigures=0;

% ........................... main code below .............................

p=haltonset(2);
pts=p(1:npts,:); x=-1+2*pts(:,1); y=-1+2*pts(:,2);

dbox=[-1 -1; 1 1]; % Bounding box, containing the points.

card_adeV=length(adeV);
re_x=zeros(ntests,card_adeV);
re_y=zeros(ntests,card_adeV);
re_xx=zeros(ntests,card_adeV);
re_xy=zeros(ntests,card_adeV);
re_yy=zeros(ntests,card_adeV);

for j=1:card_adeV
    ade=adeV(j);

    fprintf('\n \t * investigating degree %-2.0f',ade);

    for k=1:ntests

        % ...................... random polynomials  ...................

        a=rand(3,1);
        f=@(x,y) (a(1)*x+a(2)*y+a(3)).^ade;

        % ........................ derivatives  ........................

        FX=@(x,y) ade*(a(1)*x+a(2)*y+a(3)).^(ade-1)*a(1);
        FY=@(x,y) ade*(a(1)*x+a(2)*y+a(3)).^(ade-1)*a(2);
        FXX=@(x,y) ade*(ade-1)*(a(1)*x+a(2)*y+a(3)).^(ade-2)*a(1)^2;
        FYY=@(x,y) ade*(ade-1)*(a(1)*x+a(2)*y+a(3)).^(ade-2)*a(2)^2;
        FXY=@(x,y) ade*(ade-1)*(a(1)*x+a(2)*y+a(3)).^(ade-2)*a(1)*a(2);

        diff_x_ref=FX(x,y); % Evaluation of derivatives at "(x,y)".
        diff_y_ref=FY(x,y);
        diff_xx_ref=FXX(x,y);
        diff_yy_ref=FYY(x,y);
        diff_xy_ref=FXY(x,y);

        % .......................... x derivative ......................

        [rule_ref,duples,V_ref]=cheap_startup(ade,2);
        z=rule_ref(:,3);

        moms_x=mom_derivative_2D(x,y,1,0,ade,duples,dbox);
        [nodes,w_ch_x]=cheap_rule(rule_ref,V_ref,dbox,moms_x);

        x_ch=nodes(:,1); y_ch=nodes(:,2);
        fxy_ch=f(x_ch,y_ch);

        diff_x_ch=w_ch_x'*fxy_ch;


        % .......................... y derivative ......................

        [~,moms0_y]=mom_derivative_2D(x,y,0,1,ade,duples,dbox);
        w_ch_y=diag(z)*V_ref*moms0_y;
        diff_y_ch=w_ch_y'*fxy_ch;

        % .......................... xx derivative .....................

        [~,moms0_xx]=mom_derivative_2D(x,y,2,0,ade,duples,dbox);
        w_ch_xx=diag(z)*V_ref*moms0_xx;
        diff_xx_ch=w_ch_xx'*fxy_ch;

        % .......................... yy derivative .....................

        [~,moms0_yy]=mom_derivative_2D(x,y,0,2,ade,duples,dbox);
        w_ch_yy=diag(z)*V_ref*moms0_yy;
        diff_yy_ch=w_ch_yy'*fxy_ch;

        % .......................... xy derivative .....................

        [~,moms0_xy]=mom_derivative_2D(x,y,1,1,ade,duples,dbox);
        w_ch_xy=diag(z)*V_ref*moms0_xy;
        diff_xy_ch=w_ch_xy'*fxy_ch;

        % .......................... Statistics ........................

        ae_xV=diff_x_ref-diff_x_ch;
        re_x(k,j)=norm(ae_xV,2)/norm(diff_x_ref,2);

        ae_yV=diff_y_ref-diff_y_ch;
        re_y(k,j)=norm(ae_yV,2)/norm(diff_y_ref,2);

        ae_xxV=diff_xx_ref-diff_xx_ch;
        re_xx(k,j)=norm(ae_xxV,2)/norm(diff_xx_ref,2);

        ae_xyV=diff_xy_ref-diff_xy_ch;
        re_xy(k,j)=norm(ae_xyV,2)/norm(diff_xy_ref,2);

        ae_yyV=diff_yy_ref-diff_yy_ch;
        re_yy(k,j)=norm(ae_yyV,2)/norm(diff_yy_ref,2);

    end
end


% .......................... plot results  ................................

fprintf('\n \t ............................................ \n');
fprintf('\n \t Derivatives are evaluated in %5.0f pts.',npts);
fprintf('\n \t Number of random polynomials: %5.0f pts.',ntests);
fprintf('\n \t ............................................ \n');
fprintf('\n \t See figures in which we describe ');
fprintf('\n \t a) by + the norm 2 of the pointwise errors');
fprintf('\n \t    in a cloud of random points divided by the');
fprintf('\n \t    norm 2 of the derivatives in that cloud;');
fprintf('\n \t b) by a circle the logarithmic average of');
fprintf('\n \t    the quantities above.');
if savefigures == 1
    fprintf('\n \n \t All the figures are saved as eps files.');
end
fprintf('\n \t ............................................ \n \n');

figure(1)
for ii=1:card_adeV
    reL=re_x(:,ii);
    iok=reL > 0;
    log_reL=10^(mean(log10(reL(iok))));
    plot_errors(ii,adeV,reL,log_reL);
    hold on;
end
title('x-derivative')
hold off;
if savefigures == 1, saveas(gcf,'diff_2D_x.eps','epsc'); end


figure(2)
for ii=1:card_adeV
    reL=re_y(:,ii);
    iok=reL > 0;
    log_reL=10^(mean(log10(reL(iok))));
    plot_errors(ii,adeV,reL,log_reL);
    hold on;
end
title('y-derivative')
hold off;
if savefigures == 1, saveas(gcf,'diff_2D_y.eps','epsc'); end



figure(3)
for ii=1:card_adeV
    reL=re_xx(:,ii);
    iok=reL > 0;
    log_reL=10^(mean(log10(reL(iok))));
    plot_errors(ii,adeV,reL,log_reL);
    hold on;
end
title('xx-derivative')
hold off;
if savefigures == 1, saveas(gcf,'diff_2D_xx.eps','epsc'); end



figure(4)
for ii=1:card_adeV
    reL=re_xy(:,ii);
    iok=reL > 0;
    log_reL=10^(mean(log10(reL(iok))));
    plot_errors(ii,adeV,reL,log_reL);
    hold on;
end
title('xy-derivative')
hold off;
if savefigures == 1, saveas(gcf,'diff_2D_xy.eps','epsc'); end



figure(5)
for ii=1:card_adeV
    reL=re_yy(:,ii);
    iok=reL > 0;
    log_reL=10^(mean(log10(reL(iok))));
    plot_errors(ii,adeV,reL,log_reL);
    hold on;
end
title('yy-derivative')
hold off;
if savefigures == 1, saveas(gcf,'diff_2D_yy.eps','epsc'); end









%==========================================================================
% plot_errors
%==========================================================================

function plot_errors(ii,adeV,reV,log_re)

%--------------------------------------------------------------------------
% Object
%--------------------------------------------------------------------------
% Given a vector of algebraic degree of precisions "adeV", it selects the
% algebraic degree of precision "ade=adeV(ii)" and plots all the
% experimental relative errors "reV" with a coloured cross and a circle
% describing its logarithmic average "log_re"
%--------------------------------------------------------------------------

n=adeV(ii);

xmin=min(adeV);
xmax=max(adeV);
xlim([xmin xmax]);
ylim([10^(-20) 10^(-2)]);
grid on;

% Get handle to current axes.
ax = gca;
ax.XAxis.FontSize = 9;
ax.YAxis.FontSize = 9;
set(gca,'XTickLabel',{adeV})
C=colororder("glow12");

if ii <= 12
    plotstr='+';
    semilogy(n*ones(size(reV)),reV,plotstr,'color',C(ii,:)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',20,'MarkerEdgeColor','k');
else
    plotstr='+';
    semilogy(n*ones(size(reV)),reV,plotstr,'color',rand(1,3)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',20,'MarkerEdgeColor','k');
end
