
function demo_cubature_sumweights_spline

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows the sum of the absolute value of weights of the cheap
% rule in a spline-curvilinear domain, so discussing the stability of the 
% rules.
%
% In particular, it
%
% 1. computes a cheap rule of degree "ade";
% 2. evaluates the sum of the absolute values of the weights.
% 3. display results.
%--------------------------------------------------------------------------
% Important: 
%--------------------------------------------------------------------------
% This routine requires the Matlab built-in "curve fitting toolbox".
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> tic; demo_cubature_sumweights_spline; toc;
% 
%  	 ............................................  
%  	 | ade |   sum(W)   |  abs(sum(W)) |  ratio |
%  	 ............................................  
%  	   2   &  2.814e+00 &  3.436e+00 & 1.22e+00
%  	   4   &  2.814e+00 &  3.244e+00 & 1.15e+00
%  	   6   &  2.814e+00 &  3.003e+00 & 1.07e+00
%  	   8   &  2.814e+00 &  3.046e+00 & 1.08e+00
%  	  10   &  2.814e+00 &  2.997e+00 & 1.07e+00
%  	  12   &  2.814e+00 &  3.017e+00 & 1.07e+00
%  	  14   &  2.814e+00 &  3.002e+00 & 1.07e+00
%  	  16   &  2.814e+00 &  2.981e+00 & 1.06e+00
%  	 ............................................   
% 
% Elapsed time is 0.042429 seconds.
% >>
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% [1] "Effective numerical integration on complex shaped elements by
%      discrete signed measures", 2025.
%      by L. Rinaldi, A. Sommariva, M. Vianello.
% [2] "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      moments", 2025.
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% Cputime:
%--------------------------------------------------------------------------
% The demo requires, approximatively, 0.03s.
%--------------------------------------------------------------------------
% Routines.
%--------------------------------------------------------------------------
% 1. compute_spline_boundary
% 2. cheap_startup
% 3. spline_chebmom
%
% as well as subroutines called by the functions above.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 23, 2025
%..........................................................................

adeV=2:2:16;              % Define algebraic degrees of precision.
spline_order=4;           % Define spline curvilinear polygon parameters.
spline_type='periodic';



% .......................... main code below ..............................

% .................. A. Compute spline boundary parameters  ...............

% Define vertices of the curvilinear polygon.
% Notice that first and last sample point are equal.
vertices=[-1 0; -2 -1; -1.5 -2; 0 -1.6; 0 -1; -0.2 -0.5; -0.4 -0.8; ...
    -0.2 -0.9; -0.6 -1.2; -1 0];

XV=vertices(:,1); YV=vertices(:,2);
spline_parms=[spline_order length(XV)];
[Sx,Sy]=compute_spline_boundary(XV,YV,spline_parms,spline_type);




% ....................... B. Cheap rules ..................................

sum_W=zeros(size(adeV)); sum_absW=zeros(size(adeV));

for ii=1:length(adeV)
    
    ade=adeV(ii);

    

    % 1. Startup.
    [rule_refL,basis_indicesL,V_refL]=cheap_startup(ade,2);

    % 2. Moment computation.
    [~,~,cmom_orthnL] = spline_chebmom(ade,Sx,Sy,basis_indicesL);

    % 3. Determine Cheap rule.
    WW=(rule_refL(:,3)).*V_refL*cmom_orthnL;

    sum_W(ii)=sum(WW);
    sum_absW(ii)=(sum(abs(WW)));

end



% .......................... C. Statistics ................................

fprintf('\n \t ............................................  ')
fprintf('\n \t | ade |   sum(W)   |  abs(sum(W)) |  ratio |')
fprintf('\n \t ............................................  ')

for k=1:length(adeV)
    fprintf('\n \t  %2.0f   &  %1.3e &  %1.3e & %1.2e',adeV(k),sum_W(k),...
        sum_absW(k),sum_absW(k)/sum_W(k));
end


fprintf('\n \t ............................................   \n \n')