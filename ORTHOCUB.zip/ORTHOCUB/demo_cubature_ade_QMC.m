
function demo_cubature_ade_QMC

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows numerically how the cheap rules have the desired
% algebraic degree of exactness (w.r.t. QMC discrete measure).
%
% The domain is union of some balls.
%
% Starting from a QMC rule in a bounding box of the domain, having "card"
% QMC points, it computes a cheap rule of degree "n", and approximates
% "number_tests" integrals of polynomials of the form
%                 (a(1)*x+a(2)*y+a(3)*z+a(4)).^n
% where "a" is a random vector in [0,1]^4.
%
% Finally, it plots a figure displaying the relative errors and its
% average exponent.
%--------------------------------------------------------------------------
% Important.
%--------------------------------------------------------------------------
% The routine requires the Matlab-built in function "haltonset".
% In case it is not installed, it is part of the "Statistics and Machine
% Learning Toolbox".
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% [1] "Effective numerical integration on complex shaped elements by
%      discrete signed measures", 2025,
%      by L. Rinaldi, A. Sommariva, M. Vianello.
% [2] "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      moments", 2025,
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Subroutines used.
%--------------------------------------------------------------------------
% 1. QMC_union_balls
% 2. cheap_startup
% 3. dCHEBVAND_orthn
% 4. cheap_rule
% 5. plot_errors (attached below)
%
% as well as the subroutines called by the functions above.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> tic; demo_cubature_ade_QMC; toc;
%
%  	 ade:  2 card QMC:  37379 CH:     16 ratios: 4.280e-04
%  	 [log re] QMC/ref: 1.533e-03 CH/REF: 1.533e-03 QMC/CH: 3.189e-15
%
%  	 ade:  4 card QMC:  37379 CH:     54 ratios: 1.445e-03
%  	 [log re] QMC/ref: 1.977e-03 CH/REF: 1.977e-03 QMC/CH: 4.722e-15
%
%  	 ade:  6 card QMC:  37379 CH:    128 ratios: 3.424e-03
%  	 [log re] QMC/ref: 2.305e-03 CH/REF: 2.305e-03 QMC/CH: 7.357e-15
%
%  	 ade:  8 card QMC:  37379 CH:    250 ratios: 6.688e-03
%  	 [log re] QMC/ref: 2.773e-03 CH/REF: 2.773e-03 QMC/CH: 4.851e-13
%
%  	 ade: 10 card QMC:  37379 CH:    432 ratios: 1.156e-02
%  	 [log re] QMC/ref: 2.635e-03 CH/REF: 2.635e-03 QMC/CH: 7.214e-13
%
%  	 ade: 12 card QMC:  37379 CH:    686 ratios: 1.835e-02
%  	 [log re] QMC/ref: 3.400e-03 CH/REF: 3.400e-03 QMC/CH: 1.426e-12
%
%  	 ade: 14 card QMC:  37379 CH:   1024 ratios: 2.740e-02
%  	 [log re] QMC/ref: 3.163e-03 CH/REF: 3.163e-03 QMC/CH: 2.684e-12
%
%  	 ade: 16 card QMC:  37379 CH:   1458 ratios: 3.901e-02
%  	 [log re] QMC/ref: 2.941e-03 CH/REF: 2.941e-03 QMC/CH: 6.174e-12
%
%  	 ......................................................
%  	 card ratios: card_CH / card_QMC;
%  	 see figure with relative errors
%  	 ......................................................
% Elapsed time is 17.375507 seconds.
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% Routine time.
%--------------------------------------------------------------------------
% The present routine requires from about 17.4s (using the option
% "savefigures=0", i.e. no figure is saved).
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 23, 2025
%--------------------------------------------------------------------------

card_ref=10^6;     % QMC cardinality (ref.results, points in bounding box).
card=10^5;         % QMC cardinality (QMC in tests, points in bounding box).
adeV=2:2:16;       % Degree of precision of the rule.
number_tests=100;  % Polynomial tests.
savefigures=0;     % Save figures: 0: no, 1: yes.

% ........................ main code below ................................

% ........................... A. define domain ............................

% Introduce centers and radii of the balls.
card_centers=5;

p=haltonset(3);
centers=p(1:card_centers,:);

radii=0.5*ones(card_centers,1);

% Compute bounding box

xmin=centers(:,1)-radii; xmax=centers(:,1)+radii;
ymin=centers(:,2)-radii; ymax=centers(:,2)+radii;
zmin=centers(:,3)-radii; zmax=centers(:,3)+radii;

dbox_X=[min(xmin) max(xmax)];
dbox_Y=[min(ymin) max(ymax)];
dbox_Z=[min(zmin) max(zmax)];

dbox=[dbox_X; dbox_Y; dbox_Z]';




% ...................... B. QMC reference pointset ........................

% QMC points reference rule
[pts_QMC_ref,w_QMC_ref]=QMC_union_balls(card_ref,centers,radii,dbox);

% QMC initial rule
[pts_QMC,w_QMC]=QMC_union_balls(card,centers,radii,dbox);




% ...................... C. Numerical test on rules .......................

card_adeV=length(adeV);
log_aeV_QMC=zeros(1,card_adeV);
log_reV_QMC=zeros(1,card_adeV);
log_aeV_CH=zeros(1,card_adeV);
log_reV_CH=zeros(1,card_adeV);
log_aeV_CH_QMC=zeros(1,card_adeV);
log_reV_CH_QMC=zeros(1,card_adeV);

for ii=1:length(adeV)

    ade=adeV(ii);

    % .................... A. QMC cheap startup ...........................

    [ruleL_ref,basis_indicesL,VL_ref]=cheap_startup(ade,3);


    % .................... B. Compute QMC moments .........................

    V_ade_QMC = dCHEBVAND_orthn(ade,pts_QMC,dbox,basis_indicesL);
    cmom_orthnL=(w_QMC'*V_ade_QMC)';

    % .................... C. QMC cheap rule ..............................

    XYL=cheap_rule(ruleL_ref,VL_ref,dbox);
    XL=XYL(:,1); YL=XYL(:,2); ZL=XYL(:,3);
    WL=(ruleL_ref(:,4)).*VL_ref*cmom_orthnL;

    cardL_QMC=length(w_QMC); cardL_CH=length(WL); rat=cardL_CH/cardL_QMC;

    fprintf(' \n \t ade: %2.0f card QMC: %6.0f CH: %6.0f ratios: %1.3e ',...
        ade,cardL_QMC,cardL_CH,rat);

    % .................... D. Tests over random polynomials ...............

    aeV_QMC=zeros(1,number_tests);
    reV_QMC=zeros(1,number_tests);
    aeV_CH=zeros(1,number_tests);
    reV_CH=zeros(1,number_tests);
    aeV_CH_QMC=zeros(1,number_tests);
    reV_CH_QMC=zeros(1,number_tests);

    for jj=1:number_tests
        % Random polynomial integrand of degree "n"
        a=rand(4,1);
        f=@(x,y,z) (a(1)*x+a(2)*y+a(3)*z+a(4)).^ade;

        % ............. reference result ............
        f_QMC_ref=f(pts_QMC_ref(:,1),pts_QMC_ref(:,2),pts_QMC_ref(:,3));
        I_exact =w_QMC_ref'*f_QMC_ref;

        f_pts_QMC=f(pts_QMC(:,1),pts_QMC(:,2),pts_QMC(:,3));
        I_QMC =w_QMC'*f_pts_QMC;

        I_ch=WL'*f(XL,YL,ZL);

        % ... Absolute/Relative errors ...

        % QMC vs QMC ref
        aeV_QMC(jj)=abs(I_exact-I_QMC);

        if abs(I_exact) > 10^(-6) || abs(I_exact) < 10^(+12)
            reV_QMC(jj)=aeV_QMC(jj)/abs(I_exact);
        else
            reV_QMC(jj)=0;
        end

        % cheap vs QMC ref
        aeV_CH(jj)=abs(I_exact-I_ch);

        if abs(I_exact) > 10^(-6) || abs(I_exact) < 10^(+12)
            reV_CH(jj)=aeV_CH(jj)/abs(I_exact);
        else
            reV_CH(jj)=0;
        end

        % cheap vs QMC
        aeV_CH_QMC(jj)=abs(I_QMC-I_ch);

        if abs(I_exact) > 10^(-6) || abs(I_exact) < 10^(+12)
            reV_CH_QMC(jj)=aeV_CH_QMC(jj)/abs(I_exact);
        else
            reV_CH_QMC(jj)=0;
        end

    end


    % ....................... D. Statistics ...............................

    % average errors (needs log!)

    % QMC vs QMC ref
    iok1=(aeV_QMC > 0);
    log_aeV_QMC(ii)=10^(mean(log10(aeV_QMC(iok1))));

    iok2=(reV_QMC > 0);
    log_reV_QMC(ii)=10^(mean(log10(reV_QMC(iok2))));

    % cheap vs QMC ref
    iok1=(aeV_CH > 0);
    log_aeV_CH(ii)=10^(mean(log10(aeV_CH(iok1))));

    iok2=(reV_CH > 0);
    log_reV_CH(ii)=10^(mean(log10(reV_CH(iok2))));

    % cheap vs QMC
    iok1=(aeV_CH_QMC > 0);
    log_aeV_CH_QMC(ii)=10^(mean(log10(aeV_CH_QMC(iok1))));

    iok2=(reV_CH_QMC > 0);
    log_reV_CH_QMC(ii)=10^(mean(log10(reV_CH_QMC(iok2))));


    fprintf('\n \t');
    fprintf(' [log re] QMC/ref: %1.3e CH/REF: %1.3e QMC/CH: %1.3e',...
        log_reV_QMC(ii),log_reV_CH(ii),log_reV_CH_QMC(ii))
    fprintf('\n');
    % plots

    plot_errors(ii,adeV,reV_CH_QMC,log_reV_CH_QMC(ii));
    hold on;

end

hold off;
if savefigures == 1, saveas(gcf,'cub_QMC_adeC.eps','epsc'); end


fprintf('\n \t ......................................................');
fprintf('\n \t card ratios: card_CH / card_QMC;');
fprintf('\n \t see figure with relative errors');
if savefigures == 1
    fprintf('\n \n \t The figure is saved as eps file.');
end
fprintf('\n \t ...................................................... \n');


















%==========================================================================
% plot_errors
%==========================================================================

function plot_errors(ii,adeV,reV,log_re)

%--------------------------------------------------------------------------
% Object
%--------------------------------------------------------------------------
% Given a vector of algebraic degree of precisions "adeV", it selects the
% algebraic degree of precision "ade=adeV(ii)" and plots all the
% experimental relative errors "reV" with a coloured cross and a circle
% describing its logarithmic average "log_re"
%--------------------------------------------------------------------------

n=adeV(ii);

xmin=min(adeV)-1;
xmax=max(adeV)+1;
xlim([xmin xmax]);

ax = gca;

ax.XAxis.FontSize = 12;
ax.YAxis.FontSize = 12;

set(gca,'XTickLabel',{adeV})
C=colororder("glow12");

if ii <= 12
    plotstr='+';
    semilogy(n*ones(size(reV)),reV,plotstr,'color',C(ii,:)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',20,'MarkerEdgeColor','k');
else
    plotstr='+';
    semilogy(n*ones(size(reV)),reV,plotstr,'color',rand(1,3)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',20,'MarkerEdgeColor','k');
end


