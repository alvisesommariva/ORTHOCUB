
function demo_cubature_ade_splines

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows how a cubature rule with algebraic degree of precision
% "ade" defined by Orthocub routines integrates random polynomials of
% degree "ade".
%
% The domain is a spline-curvilinear polygon, that is, its sides are
% defined parametrically by splines "x=x(t)", "y=y(t)".
%
% The routine computes a cheap rule of degree "n", and approximates
% "number_tests" integrals of polynomials of the form
%                 (a(1)*x+a(2)*y+a(3)).^n
% where "a" is a random vector in [0,1]^3.
%
% Finally, it plots a figure displaying the relative errors and its
% average exponent.
%--------------------------------------------------------------------------
% Important:
%--------------------------------------------------------------------------
% The function requires the Matlab built-in "curve fitting toolbox".
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% [1] "Effective numerical integration on complex shaped elements by
%      discrete signed measures", 2025,
%      by L. Rinaldi, A. Sommariva, M. Vianello.
% [2] "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      moments", 2025,
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Examples.
%--------------------------------------------------------------------------
% >> % option "savefigures=0;"
% >> tic; demo_cubature_ade_splines; toc;
%
%
%  	 ............... aver. rel. errors ..............
%
%  	 ade:  2 log_aeV: 3.63e-16 log_reV: 3.34e-16
%  	 ade:  4 log_aeV: 1.04e-15 log_reV: 8.60e-16
%  	 ade:  6 log_aeV: 8.59e-16 log_reV: 8.25e-16
%  	 ade:  8 log_aeV: 2.32e-15 log_reV: 1.27e-15
%  	 ade: 10 log_aeV: 2.03e-15 log_reV: 2.38e-15
%  	 ade: 12 log_aeV: 2.64e-15 log_reV: 7.98e-16
%  	 ade: 14 log_aeV: 5.87e-15 log_reV: 4.28e-15
%  	 ade: 16 log_aeV: 2.78e-15 log_reV: 2.95e-15
%
%  	 ................ explanation ...................
%
%      * ade     : alg. degree of precision;
%      * log_aeV : logarithmic average absolute error;
%      * log_reV : logarithmic average relative error.
%
%  	 .................. plots ......................
%
%      Note: see relative errors and log. average in figure 1;
%      * abscissae : alg. degree of precision;
%      * ordinates : cubature relative errors;
%      * crosses   : relative error in a test;
%      * circle    : logarithmic average rel. err.
%
% Elapsed time is 2.136270 seconds.
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% Cputime:
%--------------------------------------------------------------------------
% The demo requires, approximatively, 2.13s.
%--------------------------------------------------------------------------
% Routines.
%--------------------------------------------------------------------------
% 1. compute_spline_boundary;
% 2. cheap_startup;
% 3. spline_chebmom;
% 4. cheap_rule;
% 5. exact_integral (attached below, with all its subroutines);
% 6. plot_errors;
%
% and all the subroutines called by the functions above.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 23, 2025
%--------------------------------------------------------------------------

adeV=2:2:16;              % Define algebraic degrees of precision.
spline_order=4;           % Define spline curvilinear polygon parameters.
spline_type='periodic';
number_tests=100;         % Number of random polynomials tested
savefigures=0;            % Save figures: 0: no, 1: yes.




% .......................... main code below ..............................


% .................. A. Compute spline boundary parameters  ...............

% Define vertices of the curvilinear polygon.
% Notice that first and last sample point are equal.

vertices=[-1 0; -2 -1; -1.5 -2; 0 -1.6; 0 -1; -0.2 -0.5; -0.4 -0.8; ...
    -0.2 -0.9; -0.6 -1.2; -1 0];

XV=vertices(:,1); YV=vertices(:,2);
spline_parms=[spline_order length(XV)];
[Sx,Sy]=compute_spline_boundary(XV,YV,spline_parms,spline_type);


%  ................ B. Make experiments, varying degree  ..................

fprintf('\n \n \t ............... aver. rel. errors .............. \n ');

log_aeV=zeros(1,length(adeV)); log_reV=zeros(1,length(adeV));

for ii=1:length(adeV)

    ade=adeV(ii);

    % 1. Startup.
    [rule_refL,basis_indicesL,V_refL]=cheap_startup(ade,2);

    % 2. Moment computation.
    [~,dbox,cmom_orthnL] = spline_chebmom(ade,Sx,Sy,basis_indicesL);

    % 3. Determine Cheap rule.
    XYL=cheap_rule(rule_refL,V_refL,dbox);
    XL=XYL(:,1); YL=XYL(:,2); WL=(rule_refL(:,3)).*V_refL*cmom_orthnL;

    % 4. Compute integrals over random polynomials

    aeV=zeros(1,number_tests); reV=zeros(1,number_tests);

    for jj=1:number_tests

        % Random polynomial integrand of degree "n"
        a=rand(3,1);
        f=@(x,y) (a(1)*x+a(2)*y+a(3)).^ade;

        % ................  numerical integration .........................
        I_ref = exact_integral(a(3),a(1),a(2),ade,Sx,Sy);
        I_ch = WL'*f(XL,YL);


        % ... Absolute error ...
        aeV(jj)=abs(I_ref-I_ch);

        % ... Absolute error ...
        if abs(I_ref) > 10^(-6) || abs(I_ref) < 10^(+12)
            reV(jj)=abs(I_ref-I_ch)/abs(I_ref);
        else
            reV(jj)=0;
        end
    end

    % ........................ statistics .................................

    % average error (needs log!)
    iok1=aeV > 0;
    log_aeV(ii)=10^(mean(log10(aeV(iok1))));

    iok2=reV > 0;
    log_reV(ii)=10^(mean(log10(reV(iok2))));

    % display results
    fprintf('\n \t ade: %2.0f log_aeV: %1.2e log_reV: %1.2e',...
        ade,log_aeV(ii),log_reV(ii))

    % plot results
    plot_errors(ii,adeV,reV,log_reV(ii))

end
hold off;

if savefigures == 1, saveas(gcf,'cub_splines_adeC.eps','epsc'); end




fprintf('\n \n \t ................ explanation ................... \n \n');

disp('     * ade     : alg. degree of precision;');
disp('     * log_aeV : logarithmic average absolute error;');
disp('     * log_reV : logarithmic average relative error.');

fprintf('\n \t .................. plots ...................... \n \n');

disp('     Note: see relative errors and log. average in figure 1;');
disp('     * abscissae : alg. degree of precision;');
disp('     * ordinates : cubature relative errors;');
disp('     * crosses   : relative error in a test;');
disp('     * circle    : logarithmic average rel. err.');
if savefigures == 1
    fprintf('\n \n \t The figure is saved as eps file.');
end
fprintf('\n');











%==========================================================================
% chebmom
%==========================================================================

function [Iexact] = exact_integral(a,b,c,n,Sx,Sy)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% computes the exact integral up to degree m of a total-degree polynomial
% (a+bx+cy)^n to the Lebesgue measure in a Jordan spline polygon,
% whose boundary is given by the counterclockwise concatened spline
% arcs (Sx,Sy)
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% a,b,c,n: constants for polynomial definition
% Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
% the arcs must be counterclockwise concatenated forming a Jordan curve
% Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
% i=1,...,end, with end+1:=1
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% Iexact: integral value
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% built: June 6, 2020
% modified: November 19, 2025
%--------------------------------------------------------------------------

xyw=lineint(n,Sx,Sy);
intV=intpoly(a,b,c,n,xyw(:,1:2));
Iexact=intV'*xyw(:,3);





%==========================================================================
% lineint
%==========================================================================

function xyw = lineint(m,Sx,Sy)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% computes weights and nodes for the line integral on concatenated
% spline arcs; the formula is exact on bivariate polynomials up to deg m
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% m = polynomial degree to be integrated, via its x-primitive, on the
%     spline-curvilinear domain.
% Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
% the arcs must be concatenated
% Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% xyw: 3-column array of nodes coords (cols 1-2) and weights (col 3)
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% built: March 2019
% modified: November 16, 2025.
%--------------------------------------------------------------------------

% Initialization spline structs.
dSy=struct('form',[],'breaks',[],'coefs',[],'pieces',[],'order',[],...
    'dim',[]);

% ............... Note on Matlab suggestion (line 322) ....................
% In view of the spline structures it is complicated to allocate the
% variable "xyw" with the correct dimension (it depends on the variable
% order of the splines involved in the process). Next, if "xyw" is
% initialized as suggested by Matlab then one has to introduce some
% variables for updating line 322, making the code less readable.

xyw=[];

for i=1:length(Sx)

    % Gauss-Legendre nodes and corresponding formulas on the curvilinear
    % side defined by the i-th spline.

    ord_spline=Sx(i).order; % degree is the spline order minus 1.

    k=ceil(((ord_spline-1)*(m+2))/2)+2; ab=r_jacobi(k,0,0); xw=gauss(k,ab);
    t=xw(:,1); w=xw(:,2);

    a=Sx(i).breaks(1:end-1); b=Sx(i).breaks(2:end);
    alpha=(b-a)/2; beta=(b+a)/2;
    dSy(i)=fnder(Sy(i));
    for j=1:length(a)
        nodes=alpha(j)*t+beta(j);
        wloc=w*alpha(j);
        xywL=[ppval(Sx(i),nodes) ppval(Sy(i),nodes) ...
            wloc.*ppval(dSy(i),nodes)];
        xyw=[xyw; xywL];
    end

end





%==========================================================================
% intcvand
%==========================================================================

function intV = intpoly(a,b,c,n,pts)

%--------------------------------------------------------------------------
% Object
%--------------------------------------------------------------------------
% Computes by recurrence an x-primitive of the polynomial (a+bx+cy)^n on a
% 2d arbitrarily located mesh "pts".
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% a,b,c,n: polynomial parameters
% pts: 2-column array of mesh point coordinates
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% intV: x-primitive of (a+bx+cy)^n evaluation at pts (column vector)
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% built: March 2019
% modified: November 19, 2025.
%--------------------------------------------------------------------------

x=pts(:,1);
y=pts(:,2);

if (n > 0)
    intV=(1/b)*(1/(n+1))*(a+b*x+c*y).^(n+1);
else
    intV=x;
end





%==========================================================================
% r_jacobi
%==========================================================================

function ab=r_jacobi(N,a,b)
%R_JACOBI Recurrence coefficients for monic Jacobi polynomials.
%   AB=R_JACOBI(N,A,B) generates the Nx2 array AB of the first
%   N recurrence coefficients for the monic Jacobi polynomials
%   orthogonal on [-1,1] relative to the weight function
%   w(x)=(1-x)^A*(1+x)^B. The call AB=R_JACOBI(N,A) is the same
%   as AB=R_JACOBI(N,A,A) and AB=R_JACOBI(N) the same as
%   AB=R_JACOBI(N,0,0).
%
%   Supplied by Dirk Laurie, 6-22-1998; edited by Walter
%   Gautschi, 4-4-2002.

if nargin<2, a=0; end
if nargin<3, b=a; end
if((N<=0)||(a<=-1)||(b<=-1))
    error('parameter(s) out of range')
end
nu=(b-a)/(a+b+2);
if a+b+2 > 128
    mu=exp((a+b+1)*log(2)+((gammaln(a+1)+gammaln(b+1))-gammaln(a+b+2)));
else
    mu=2^(a+b+1)*((gamma(a+1)*gamma(b+1))/gamma(a+b+2));
end
if N==1, ab=[nu mu]; return, end
N=N-1; n=1:N; nab=2*n+a+b;
A=[nu (b^2-a^2)*ones(1,N)./(nab.*(nab+2))];
n=2:N; nab=nab(n);
B1=4*(a+1)*(b+1)/((a+b+2)^2*(a+b+3));
B=4*(n+a).*(n+b).*n.*(n+a+b)./((nab.^2).*(nab+1).*(nab-1));
ab=[A' [mu; B1; B']];





%==========================================================================
% gauss
%==========================================================================

function xw=gauss(N,ab)
%GAUSS Gauss quadrature rule.
%   GAUSS(N,AB) generates the Nx2 array XW of Gauss quadrature
%   nodes and weights for a given weight function W. The nodes,
%   in increasing order, are placed into the first column of XW,
%   and the corresponding weights into the second column. The
%   weight function W is specified by the Nx2 input array AB
%   of recurrence coefficients for the polynomials orthogonal
%   with respect to the weight function W.

N0=size(ab,1); if N0<N, error('input array ab too short'), end
J=zeros(N);
for n=1:N, J(n,n)=ab(n,1); end
for n=2:N
    J(n,n-1)=sqrt(ab(n,2));
    J(n-1,n)=J(n,n-1);
end
[V,D]=eig(J);
[D,I]=sort(diag(D));
V=V(:,I);
xw=[D ab(1,2)*V(1,:)'.^2];





%==========================================================================
% plot_errors
%==========================================================================

function plot_errors(ii,adeV,reV,log_re)


%--------------------------------------------------------------------------
% Object
%--------------------------------------------------------------------------
% Given a vector of algebraic degree of precisions "adeV", it selects the
% algebraic degree of precision "ade=adeV(ii)" and plots all the
% experimental relative errors "reV" with a coloured cross and a circle
% describing its logarithmic average "log_re"
%--------------------------------------------------------------------------

n=adeV(ii);

xmin=min(adeV)-1;
xmax=max(adeV)+1;
xlim([xmin xmax]);

% Get handle to current axes.
ax = gca;
ax.XAxis.FontSize = 12;
ax.YAxis.FontSize = 12;
set(gca,'XTickLabel',{adeV})
C=colororder("glow12");


if ii <= 12
    plotstr='+';
    semilogy(n*ones(size(reV)),reV,plotstr,'color',C(ii,:)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',20,'MarkerEdgeColor','k');
else
    plotstr='+';
    semilogy(n*ones(size(reV)),reV,plotstr,'color',rand(1,3)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',20,'MarkerEdgeColor','k');
end
