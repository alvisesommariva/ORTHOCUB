
function demo_cubature_weights_QMC

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows the distribution of weights of the cheap rule in a
% domain that is the union of balls. The moments are computed by a QMC rule
% based on Halton points in the bounding box of the domain.
%
% In particular,
% 1. it computes a QMC rule on the domain;
% 2. from the rule above, it determines a cheap rule of degree "ade";
% 3. plots the distribution of the weights.
%--------------------------------------------------------------------------
% Important.
%--------------------------------------------------------------------------
% The routine requires the Matlab-built in function "haltonset".
% In case it is not installed, it is part of the "Statistics and Machine
% Learning Toolbox".
%--------------------------------------------------------------------------
% Subroutines used.
%--------------------------------------------------------------------------
% 1. QMC_union_balls
% 2. cheap_startup
% 3. dCHEBVAND_orthn
%
% as well as the subroutines called by the functions above.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% [1] "Effective numerical integration on complex shaped elements by
%      discrete signed measures", 2025.
%      by L. Rinaldi, A. Sommariva, M. Vianello.
% [2] "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      moments", 2025.
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> tic; demo_cubature_weights_QMC; toc
%
% 	 .......... Settings/Info  ..........
%
% 	 ade cheap                     : 10
% 	 cardinality cheap rule        : 432
%
% 	 See figure with sorted weights
%
% 	 .....................................
% Elapsed time is 0.248515 seconds.
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% Routine time.
%--------------------------------------------------------------------------
% The present routine requires about 0.24s.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 23, 2025
%--------------------------------------------------------------------------

card_QMC=10^5;    % QMC cardinality (in bounding box!).
ade=10;           % Degree of precision of the rule.
savefigures=0;    % Save figures: 0: no, 1: yes.




% ........................ main code below ................................

% ........................... A. define domain ............................

% Introduce centers and radii of the balls.
card_centers=5;

p=haltonset(3);
centers=p(1:card_centers,:);

radii=0.5*ones(card_centers,1);

% Compute bounding box

xmin=centers(:,1)-radii; xmax=centers(:,1)+radii;
ymin=centers(:,2)-radii; ymax=centers(:,2)+radii;
zmin=centers(:,3)-radii; zmax=centers(:,3)+radii;

dbox_X=[min(xmin) max(xmax)];
dbox_Y=[min(ymin) max(ymax)];
dbox_Z=[min(zmin) max(zmax)];

dbox=[dbox_X; dbox_Y; dbox_Z]';




% ............................. B. QMC rule ...............................
[pts_QMC,w_QMC]=QMC_union_balls(card_QMC,centers,radii,dbox);




% ........................... B. QMC/cheap rule ...........................

% ........................ 1. QMC cheap startup ...........................

[ruleL_ref,basis_indicesL,VL_ref]=cheap_startup(ade,3);


% ........................ 2. Compute QMC moments .........................

V_ade_QMC = dCHEBVAND_orthn(ade,pts_QMC,dbox,basis_indicesL);
cmom_orthnL=(w_QMC'*V_ade_QMC)';


% ........................ 3. QMC cheap weights ...........................

WL=(ruleL_ref(:,4)).*VL_ref*cmom_orthnL;




% ....................... C. Plot weights .................................

clf;
figure(1);
WWo=sort(WL);
my_color='r';
grid on;
hold on;
plot(1:length(WWo),WWo,'o','MarkerEdgeColor',my_color,...
    'MarkerFaceColor',my_color,'MarkerSize',3);
hold off;
if savefigures == 1, saveas(gcf,'cub_QMC_weightsC.eps','epsc'); end




% ....................... D. Statistics ................................

fprintf('\n \t .......... Settings/Info  ..........  \n ')
fprintf('\n \t ade cheap                     : %-7.0f',ade);
fprintf('\n \t cardinality cheap rule        : %-7.0f',length(WL));
fprintf('\n \n \t See figure with sorted weights \n');
if savefigures == 1
    fprintf('\n \n \t The figure is saved as eps file.');
end
fprintf('\n \t .....................................  \n ')






