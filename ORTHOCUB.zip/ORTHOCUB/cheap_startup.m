
function [rule_ref,basis_indices,V_ref]=cheap_startup(ade,d)

%--------------------------------------------------------------------------
% Object.
%--------------------------------------------------------------------------
% The cheap algorithm requires a startup that can be used for rules over
% domains in "R^d", typically "d=2" or "d=3".
%
% The variables defined here are independent from the domain and can be
% computed and even stored for determining rules with degree of exactness
% "ade" on any domain (in the case "d=2" or "d=3").
%--------------------------------------------------------------------------
% Input.
%--------------------------------------------------------------------------
% ade : algebraic degree of precision of the rule.
% d   : dimension of the problem.
%--------------------------------------------------------------------------
% Output.
%--------------------------------------------------------------------------
% rule_ref: precomputed nodes and weights of a tensorial rule, in  
%    the domain [-1,1]^d (d=2,3).
%    The first "d" columns represent the coordinates of the nodes,
%    the last column the respective weights.
%
% V_ref: Vandermonde matrix w.r.t. orthonormal basis of tensorial Chebyshev 
%    weight function in [-1,1]^d.
%
% basis_indices : nchoosek(n+d,n) x d matrix of indices describing the
%     tensorial basis. Example: if "d=2" then the i-th row is a couple
%     (h,k) and the basis element will be "T_h(x) T_k(y)" with "T_h" 
%     univariate orthonormal Chebyshev polynomial of the first kind.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% [1] "Effective numerical integration on complex shaped elements by
%      discrete signed measures", 2025.
%      by L. Rinaldi, A. Sommariva, M. Vianello.
% [2] "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      moments", 2025.
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) Core(TM) Ultra 5 125H
% 3.60 GHz with 16 GB of RAM.
%--------------------------------------------------------------------------
% External routines.
%--------------------------------------------------------------------------
% 1. dCHEBVAND_orthn
% 2. mono_next_grlex
% 3. cub_square_mpx
% 4. cub_cube_mpx
%
% as well as subroutines called by the functions above.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 21, 2025
%--------------------------------------------------------------------------

if (d > 3), error('It must be d=2 or d=3 in cheap_startup'), end

switch d

    case 2
        % Morrow-Patterson minimal rule with degree of exactness 2n+1 on
        % the unit-square [-1,1] w.r.t. the weight function
        %
        %             w(x,y)=(1/pi^2)*(1-x^2)^(-1/2)*(1-y^2)^(-1/2).
        %
        % We scale weights to those of tens. cheb. weight function
        %
        %             t(x,y)=(1-x^2)^(-1/2)*(1-y^2)^(-1/2).
        %

        % A. compute rule (w.r.t. t(x,y))
        rule_ref=cub_square_mpx(2*ade);
        c=1/pi^2;
        rule_ref(:,end)=rule_ref(:,end)/c;


    case 3

        % A. compute rule
        % Morrow-Patterson minimal rule with degree of exactness 2n+1 on
        % the unit-cube [-1,1]^3 w.r.t. the weight function
        %
        %  w(x,y,z)=(1/pi^3)*(1-x^2)^(-1/2)*(1-y^2)^(-1/2)*(1-z^2)^(-1/2).
        %
        % We scale weights to those of tens. cheb. weight function
        %
        %  t(x,y,z)=(1-x^2)^(-1/2)*(1-y^2)^(-1/2)*(1-y^2)^(-1/2).
        %

        % A. compute rule (w.r.t. t(x,y,z))
        rule_ref=cub_cube_mpx(2*ade);
        c=1/pi^3;
        rule_ref(:,end)=rule_ref(:,end)/c;

end


% B. compute basis indices (tens. cheb. basis ordering) 
N = nchoosek(ade+d,d); basis_indices = zeros(N,d);
for i=2:N
    basis_indices(i,:) = mono_next_grlex(d,basis_indices(i-1,:)); 
end


% C. reference Vandermonde matrix
X=rule_ref(:,1:d);
box_ch=[-ones(1,d); ones(1,d)];
V_ref = dCHEBVAND_orthn(ade,X,box_ch,basis_indices);

