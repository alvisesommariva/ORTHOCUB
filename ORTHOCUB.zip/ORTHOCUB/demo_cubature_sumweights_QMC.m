
function demo_cubature_sumweights_QMC

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo computes the sum of weights of QMC cheap rules in a domain that
% is the union of some balls.
% Next it computes also stability parameters as sum of absolute values of
% the weights and the condition number (for cubature).
%
% In details, it
% 1. computes QMC rule on a test domain (starting from "card" Halton points
%    in a bounding box of the integration domain);
% 2. computes a cheap rule of degree "ade";
% 3. computes sum of weights as well as the sum of their absolute values;
% 4. writes results.
%--------------------------------------------------------------------------
% Important.
%--------------------------------------------------------------------------
% The routine requires the Matlab-built in function "haltonset".
% In case it is not installed, it is part of the "Statistics and Machine 
% Learning Toolbox".
%--------------------------------------------------------------------------
% Subroutines used.
%--------------------------------------------------------------------------
% 1. QMC_union_balls
% 2. cheap_startup
% 3. dCHEBVAND_orthn
% 4. cheap_rule
%
% as well as the subroutines called by the functions above.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% [1] "Effective numerical integration on complex shaped elements by
%      discrete signed measures", 2025.
%      by L. Rinaldi, A. Sommariva, M. Vianello.
% [2] "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      moments", 2025.
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> tic; demo_cubature_sumweights_QMC; toc
%
% ...............................................
% | ade |   sum(W)   |  abs(sum(W)) |  ratio |
% ...............................................
%   2   &  1.962e+00 &  3.081e+00 & 1.57e+00
%   4   &  1.962e+00 &  2.808e+00 & 1.43e+00
%   6   &  1.962e+00 &  2.502e+00 & 1.28e+00
%   8   &  1.962e+00 &  2.500e+00 & 1.27e+00
%  10   &  1.962e+00 &  2.381e+00 & 1.21e+00
%  12   &  1.962e+00 &  2.320e+00 & 1.18e+00
%  14   &  1.962e+00 &  2.334e+00 & 1.19e+00
%  16   &  1.962e+00 &  2.278e+00 & 1.16e+00
% ...............................................
%
% Elapsed time is 1.624036 seconds.
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% Routine time.
%--------------------------------------------------------------------------
% The present routine requires about 1.62s.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 23, 2025
%--------------------------------------------------------------------------

card=10^5; % QMC cardinality (QMC in tests).
adeV=2:2:16; % Degree of precision of the rule.

% ........................ main code below ................................

% ........................... A. define domain ............................

% Introduce centers and radii of the balls.
card_centers=5;

p=haltonset(3);
centers=p(1:card_centers,:);

radii=0.5*ones(card_centers,1);

% Compute bounding box

xmin=centers(:,1)-radii; xmax=centers(:,1)+radii;
ymin=centers(:,2)-radii; ymax=centers(:,2)+radii;
zmin=centers(:,3)-radii; zmax=centers(:,3)+radii;

dbox_X=[min(xmin) max(xmax)];
dbox_Y=[min(ymin) max(ymax)];
dbox_Z=[min(zmin) max(zmax)];

dbox=[dbox_X; dbox_Y; dbox_Z]';




% ...................... B. QMC reference pointset ........................

% QMC initial rule
[pts_QMC,w_QMC]=QMC_union_balls(card,centers,radii,dbox);




% ...................... C. Numerical test on rules .......................

card_adeV=length(adeV);
sum_W=zeros(1,card_adeV);
sum_absW=zeros(1,card_adeV);

for ii=1:length(adeV)

    ade=adeV(ii);

    % .................... 1. QMC cheap startup ...........................

    [ruleL_ref,basis_indicesL,VL_ref]=cheap_startup(ade,3);


    % .................... 2. Compute QMC moments .........................

    V_ade_QMC = dCHEBVAND_orthn(ade,pts_QMC,dbox,basis_indicesL);
    cmom_orthnL=(w_QMC'*V_ade_QMC)';

    % .................... 3. QMC cheap rule ..............................
    WL=(ruleL_ref(:,4)).*VL_ref*cmom_orthnL;

    % .................... 4. sums weights ..............................
    sum_W(ii)=sum(WL);
    sum_absW(ii)=sum(abs(WL));

end

% ....................... D. Statistics ................................

fprintf('\n \t ...............................................   ')
fprintf('\n \t | ade |   sum(W)   |  abs(sum(W)) |  ratio |')
fprintf('\n \t ...............................................   ')

for k=1:length(adeV)
    fprintf('\n \t  %2.0f   &  %1.3e &  %1.3e & %1.2e',adeV(k),sum_W(k),...
        sum_absW(k),sum_absW(k)/sum_W(k));
end


fprintf('\n \t ...............................................   \n \n')














