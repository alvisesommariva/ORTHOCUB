
function demo_derivative_weights_3D

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% The purpose of this routine is to compute at any degree "ade",
%
% 1. for any point of a pointset in [-1,1]^3 we compute the sum of the
%    absolute values of weights, used to determine directional derivatives;
%
% 2. we determine for some directional derivatives the maximum of the
%    quantity above;
%
% 3. we plot these quantities.
%--------------------------------------------------------------------------
% Important.
%--------------------------------------------------------------------------
% The routine requires the Matlab-built in function "haltonset".
% In case it is not installed, it is part of the "Statistics and Machine
% Learning Toolbox".
%--------------------------------------------------------------------------
% External routines
%--------------------------------------------------------------------------
% 1. cheap_startup2
% 2. mom_derivative_3D
% as well as the procedures potentially called by the routines above.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% [1]  "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      moments", 2025,
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> tic;demo_derivative_weights_3D;toc
%
% * investigating degree: 1
% * investigating degree: 2
% * investigating degree: 3
% * investigating degree: 4
% * investigating degree: 5
% * investigating degree: 6
% * investigating degree: 7
% * investigating degree: 8
% * investigating degree: 9
% * investigating degree: 10
% * investigating degree: 11
% * investigating degree: 12
% * investigating degree: 13
% * investigating degree: 14
% * investigating degree: 15
% * investigating degree: 16
%
%  	 ade |    x    |    y    |    z    |
% 	 ....................................
% 	 1  & 1.0e+00 &  1.0e+00 & 1.0e+00
% 	 2  & 5.4e+00 &  5.4e+00 & 5.4e+00
% 	 3  & 1.4e+01 &  1.4e+01 & 1.4e+01
% 	 4  & 3.0e+01 &  3.0e+01 & 3.0e+01
% 	 5  & 5.3e+01 &  5.3e+01 & 5.3e+01
% 	 6  & 8.6e+01 &  8.6e+01 & 8.6e+01
% 	 7  & 1.3e+02 &  1.3e+02 & 1.3e+02
% 	 8  & 1.8e+02 &  1.8e+02 & 1.8e+02
% 	 9  & 2.5e+02 &  2.5e+02 & 2.5e+02
% 	10  & 3.3e+02 &  3.3e+02 & 3.3e+02
% 	11  & 4.3e+02 &  4.3e+02 & 4.3e+02
% 	12  & 5.4e+02 &  5.4e+02 & 5.4e+02
% 	13  & 6.6e+02 &  6.6e+02 & 6.6e+02
% 	14  & 8.0e+02 &  8.0e+02 & 8.0e+02
% 	15  & 9.6e+02 &  9.6e+02 & 9.6e+02
% 	16  & 1.1e+03 &  1.1e+03 & 1.1e+03
%
%  	 ade |    xx   |    yy    |    zz   |    xy   |    xz   |    yz
% 	 ................................................................
%  	 1  & 0.0e+00 &  0.0e+00 & 0.0e+00 & 0.0e+00 & 0.0e+00 & 0.0e+00
%  	 2  & 5.3e+00 &  5.3e+00 & 5.3e+00 & 1.8e+00 & 1.8e+00 & 1.8e+00
%  	 3  & 3.3e+01 &  3.3e+01 & 3.3e+01 & 7.8e+00 & 7.8e+00 & 7.8e+00
%  	 4  & 1.2e+02 &  1.2e+02 & 1.2e+02 & 3.8e+01 & 3.8e+01 & 3.9e+01
%  	 5  & 3.2e+02 &  3.2e+02 & 3.2e+02 & 8.9e+01 & 8.9e+01 & 8.9e+01
%  	 6  & 7.4e+02 &  7.4e+02 & 7.4e+02 & 2.1e+02 & 2.1e+02 & 2.2e+02
%  	 7  & 1.5e+03 &  1.5e+03 & 1.5e+03 & 4.2e+02 & 4.2e+02 & 4.2e+02
%  	 8  & 2.8e+03 &  2.8e+03 & 2.8e+03 & 7.8e+02 & 7.8e+02 & 7.8e+02
%  	 9  & 4.8e+03 &  4.8e+03 & 4.8e+03 & 1.3e+03 & 1.3e+03 & 1.3e+03
%  	10  & 7.7e+03 &  7.7e+03 & 7.7e+03 & 2.1e+03 & 2.1e+03 & 2.1e+03
%  	11  & 1.2e+04 &  1.2e+04 & 1.2e+04 & 3.3e+03 & 3.3e+03 & 3.3e+03
%  	12  & 1.8e+04 &  1.8e+04 & 1.8e+04 & 4.9e+03 & 4.9e+03 & 4.9e+03
%  	13  & 2.6e+04 &  2.6e+04 & 2.6e+04 & 7.0e+03 & 7.0e+03 & 7.0e+03
%  	14  & 3.6e+04 &  3.6e+04 & 3.6e+04 & 9.8e+03 & 9.8e+03 & 9.8e+03
%  	15  & 5.0e+04 &  5.0e+04 & 5.0e+04 & 1.3e+04 & 1.3e+04 & 1.3e+04
%  	16  & 6.7e+04 &  6.7e+04 & 6.7e+04 & 1.8e+04 & 1.8e+04 & 1.8e+04
%
%  	 ............................................
%
%  	 Derivatives are evaluated in 10000 pts.
%  	 ............................................
%
%  	 See figure in which we describe at any degree
%  	 the maximum sum of absolute weights.
%  	 ............................................
%
% Elapsed time is 20.063796 seconds.
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% Cputime.
%--------------------------------------------------------------------------
% The procedure requires about 20s (in case the figures are not saved).
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 22, 2025
%--------------------------------------------------------------------------

adeV=1:1:16;

% Number of points in [-1,1]^3 in which the derivatives must be computed.
npts=10000;

% Save figures: 0: no, 1: yes.
savefigures=0;

% ........................... main code below .............................

p=haltonset(3);
pts=p(1:npts,:); x=-1+2*pts(:,1); y=-1+2*pts(:,2); z=-1+2*pts(:,3);

dbox=[-1 -1 -1; 1 1 1]; % Bounding box, containing the points.

card_adeV=length(adeV);
sum_absw_x=zeros(1,card_adeV);
sum_absw_y=zeros(1,card_adeV);
sum_absw_z=zeros(1,card_adeV);
sum_absw_xx=zeros(1,card_adeV);
sum_absw_yy=zeros(1,card_adeV);
sum_absw_zz=zeros(1,card_adeV);
sum_absw_xy=zeros(1,card_adeV);
sum_absw_xz=zeros(1,card_adeV);
sum_absw_yz=zeros(1,card_adeV);

for j=1:card_adeV
    ade=adeV(j);

    fprintf('\n \t * investigating degree: %-2.0f',ade);

    % ....................... x derivative ............................

    [rule_ref,duples,V_ref]=cheap_startup2(ade,3);
    z3=rule_ref(:,4);
    [~,moms0_x]=mom_derivative_3D(x,y,z,1,0,0,ade,duples,dbox);
    w_ch_x=diag(z3)*V_ref*moms0_x;
    sum_absw_x(j)=max(sum(abs(w_ch_x),1));


    % ....................... y derivative ............................

    [~,moms0_y]=mom_derivative_3D(x,y,z,0,1,0,ade,duples,dbox);
    w_ch_y=diag(z3)*V_ref*moms0_y;
    sum_absw_y(j)=max(sum(abs(w_ch_y),1));

    % ....................... z derivative ............................

    [~,moms0_z]=mom_derivative_3D(x,y,z,0,0,1,ade,duples,dbox);
    w_ch_z=diag(z3)*V_ref*moms0_z;
    sum_absw_z(j)=max(sum(abs(w_ch_z),1));


    % ....................... xx derivative ...........................

    [~,moms0_xx]=mom_derivative_3D(x,y,z,2,0,0,ade,duples,dbox);
    w_ch_xx=diag(z3)*V_ref*moms0_xx;
    sum_absw_xx(j)=max(sum(abs(w_ch_xx),1));

    % ....................... yy derivative ...........................

    [~,moms0_yy]=mom_derivative_3D(x,y,z,0,2,0,ade,duples,dbox);
    w_ch_yy=diag(z3)*V_ref*moms0_yy;
    sum_absw_yy(j)=max(sum(abs(w_ch_yy),1));

    % ....................... zz derivative ...........................

    [~,moms0_zz]=mom_derivative_3D(x,y,z,0,0,2,ade,duples,dbox);
    w_ch_zz=diag(z3)*V_ref*moms0_zz;
    sum_absw_zz(j)=max(sum(abs(w_ch_zz),1));

    % ....................... xy derivative ...........................

    [~,moms0_xy]=mom_derivative_3D(x,y,z,1,1,0,ade,duples,dbox);
    w_ch_xy=diag(z3)*V_ref*moms0_xy;
    sum_absw_xy(j)=max(sum(abs(w_ch_xy),1));

    % ....................... xz derivative ...........................

    [~,moms0_xz]=mom_derivative_3D(x,y,z,1,0,1,ade,duples,dbox);
    w_ch_xz=diag(z3)*V_ref*moms0_xz;
    sum_absw_xz(j)=max(sum(abs(w_ch_xz),1));

    % ....................... xz derivative ...........................

    [~,moms0_yz]=mom_derivative_3D(x,y,z,0,1,1,ade,duples,dbox);
    w_ch_yz=diag(z3)*V_ref*moms0_yz;
    sum_absw_yz(j)=max(sum(abs(w_ch_yz),1));

    % .......................... statistics .........................

end



% .......................... statistics .........................

fprintf('\n \n \n \t ')
fprintf('ade |    x    |    y    |    z    |\n');
fprintf('\t ....................................\n');
for j=1:card_adeV
    ade=adeV(j);
    fprintf('\t');
    fprintf('%2.0f  & %1.1e &  %1.1e & %1.1e ',...
        ade,sum_absw_x(j),sum_absw_y(j),sum_absw_z(j));
    fprintf('\n');
end


% .......................... statistics .........................
fprintf('\n \t ')
fprintf('ade|    xx   |    yy    |    zz   |    xy   |    xz   |    yz');
fprintf('\n \t')
fprintf('...............................................................');
for j=1:card_adeV
    ade=adeV(j);
    fprintf('\n \t');
    fprintf('%2.0f  & %1.1e &  %1.1e & %1.1e & %1.1e & %1.1e & %1.1e',...
        ade,sum_absw_xx(j),sum_absw_yy(j),sum_absw_zz(j),sum_absw_xy(j),...
        sum_absw_xz(j),sum_absw_yz(j));

end

% .......................... plot results  ................................
fprintf('\n');
fprintf('\n \t ............................................ \n');
fprintf('\n \t Derivatives are evaluated in %5.0f pts.',npts);
fprintf('\n \t ............................................ \n');
fprintf('\n \t See figure in which we describe at any degree');
fprintf('\n \t the maximum sum of absolute weights values.');
if savefigures == 1
    fprintf('\n \n \t The figure is saved as eps file.');
end
fprintf('\n \t ............................................ \n \n');

clf;
figure(1)
lw=1; % linewidth
ms=6; % markersize

for ii=1:card_adeV
    semilogy(adeV,sum_absw_x,'bo-','MarkerSize',ms,'LineWidth',lw);
    hold on;
    semilogy(adeV,sum_absw_xx,'co-','MarkerSize',ms,'LineWidth',lw);
    semilogy(adeV,sum_absw_xy,'rd-','MarkerSize',ms,'LineWidth',lw);
end
grid on;
legend('x, y, z','xx, yy, zz','xy, xz, yz');
legend('Location','northwest')
hold off;
if savefigures == 1, saveas(gcf,'diff_weights_3D.eps','epsc'); end







