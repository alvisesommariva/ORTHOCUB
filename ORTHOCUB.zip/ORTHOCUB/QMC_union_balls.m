
function [pts_QMC,w_QMC]=QMC_union_balls(card,centers,radii,dbox)

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo, computes a QMC rule on the union of balls. 
%
% Describing by "dbox" the bounding box of the union of balls, in which the 
% i-th balls is defined by B_i=B(centers(i,:),radii(i)), the procedure 
% a) determines "card" Halton points in the bounding box, 
% b) find those in the union of balls,
% c) compute the weights of the rule.
%
% The coordinates of the bounding box (cartesian parallelepiped containing
% the domain), say [xmin,xmax] x [ymin,ymax] x [zmin,zmax]   are given as 
%
%                    dbox=[xmin ymin zmin; xmax ymax zmax].
%--------------------------------------------------------------------------
% Important.
%--------------------------------------------------------------------------
% The routine requires the Matlab-built in function "haltonset".
% In case it is not installed, it is part of the "Statistics and Machine 
% Learning Toolbox".
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% [1] "Effective numerical integration on complex shaped elements by
%      discrete signed measures", 2025,
%      by L. Rinaldi, A. Sommariva, M. Vianello.
% [2] "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      moments", 2025,
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 20, 2025
%--------------------------------------------------------------------------

% ................. Halton pointset in [0,1]^3 ............................

p=haltonset(3);
pts_ud_ref=p(1:card,:);

% ................. Scaling Halton pointset in the bounding box ........... 

pts_ud_bb(:,1)=dbox(1,1)+diff(dbox(:,1))*pts_ud_ref(:,1);
pts_ud_bb(:,2)=dbox(1,2)+diff(dbox(:,2))*pts_ud_ref(:,2);
pts_ud_bb(:,3)=dbox(1,3)+diff(dbox(:,3))*pts_ud_ref(:,3);

% ................. Finding Halton points in unions of balls...............

in=zeros(1,card); ip=in;

for k=1:card
    in(k)=0;
    pts=pts_ud_bb(k,:);
    dist_centers=sqrt( (centers(:,1)-pts(1)).^2 + ...
        (centers(:,2)-pts(2)).^2 + (centers(:,3)-pts(3)).^2 );
    index=( dist_centers <= radii );
    ip(k)=(sum(index) > 0);
end

ind2=(ip==1);
pts_QMC=pts_ud_bb(ind2,:);

card_int=size(pts_QMC,1);

% ................... Computing QMC weights ............................... 

vol_bb=(diff(dbox(:,1)))*(diff(dbox(:,2)))*(diff(dbox(:,3)));
w_QMC=(vol_bb/card)*ones(card_int,1);