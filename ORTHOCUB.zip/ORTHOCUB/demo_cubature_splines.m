
function demo_cubature_splines

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows the quality of numerical integration of some test
% functions.
%
% The domain is a curvilinear polygon, whose sides are defined by
% parametric splines "x=x(t)", "y=y(t)".
%
% The routine approximates the integrals of 5 test functions, with
% different regularity, that is
%
%     exp(-(x.^2+y.^2))
%     (x.^2+y.^2).^(11/2)
%     (x.^2+y.^2).^(3/2)
%     (0.3+0.1*x-0.2*y).^30
%     (1.1+0.5*x-0.2*y).^10
%
% by cheap rules with different algebraic degree of precision.
%--------------------------------------------------------------------------
% Important: 
%--------------------------------------------------------------------------
% This demo requires the Matlab built-in "curve fitting toolbox".
%--------------------------------------------------------------------------
% Related papers:
%--------------------------------------------------------------------------
% [1] "Effective numerical integration on complex shaped elements by
%      discrete signed measures", 2025.
%      by L. Rinaldi, A. Sommariva, M. Vianello.
% [2] "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      moments", 2025.
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Comparisons with other routines:
%--------------------------------------------------------------------------
% Below we integrate the test functions in the attached function
% "test_functions" by Splinegauss algorithm, the algorithm "cheap" in [1]
% based on tensorial Chebyshev rules and finally the one presented in [2]
%
% % RESULTS BY SPLINEGAUSS (ade = 30)
% % 3.219100103382403e-01
% % 8.009367758620293e+03
% % 1.611081875630305e+01
% % 6.320948879535272e-08
% % 6.575801462976077e+00
%
% % VIA CHEAP (ade = 30), see [1]
% % 3.219100103382405e-01
% % 8.009367758620305e+03
% % 1.611081876608904e+01
% % 6.320948879535646e-08
% % 6.575801462976081e+00
%
% % VIA ORTHOCUB (ade = 30)
% % 3.219100103382403e-01
% % 8.009367758620291e+03
% % 1.611081874924837e+01
% % 6.320948879535543e-08
% % 6.575801462976074e+00
%--------------------------------------------------------------------------
% Examples.
%--------------------------------------------------------------------------
% >> % setting "savefigures=0"
% >> tic; demo_cubature_splines; toc
%
% .............. relative errors ................
%
% |ade |  f1   |  f2   |  f3   |  f4   |  f5  |
% ...............................................
%   2  & 7e-01 & 1e+00 & 3e-02 & 1e+01 & 4e-01
%   4  & 3e-02 & 3e-02 & 5e-04 & 1e+01 & 6e-02
%   6  & 3e-04 & 4e-03 & 6e-06 & 2e+00 & 5e-03
%   8  & 2e-04 & 3e-05 & 3e-06 & 7e-01 & 1e-05
%  10  & 1e-06 & 1e-08 & 2e-07 & 5e-02 & 3e-15
%  12  & 4e-08 & 3e-09 & 9e-08 & 1e-02 & 9e-16
%  14  & 3e-08 & 3e-11 & 8e-08 & 1e-03 & 3e-15
%  16  & 8e-10 & 4e-12 & 2e-09 & 6e-05 & 1e-15
%
% ................ integrands ...................
%
%  f1: exp(-(x.^2+y.^2))
%  f2: (x.^2+y.^2).^(11/2)
%  f3: (x.^2+y.^2).^(3/2)
%  f4: (0.3+0.1*x-0.2*y).^30
%  f5: (1.1+0.5*x-0.2*y).^10
%
% .................. plots ......................
%
%  Note: see domain in figure 1
% * green dots : nonnegative weights;
% * red dots   : negative weights.
%
% Elapsed time is 0.783277 seconds.
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% Cputime:
%--------------------------------------------------------------------------
% The demo requires, approximatively, 0.78s.
%--------------------------------------------------------------------------
% Routines.
%--------------------------------------------------------------------------
% 1. compute_spline_boundary
% 2. cheap_startup
% 3. spline_chebmom
% 4. cheap_rule
% 5. test_functions (attached below)
%
% and all subroutines called by the functions above.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 23, 2025
%--------------------------------------------------------------------------

adeV=2:2:16;              % Define algebraic degrees of precision.
spline_order=4;           % Define spline curvilinear polygon parameters.
spline_type='periodic';
num_functions=5;          % Number of functions tested
savefigures=0;            % Save figures: 0: no, 1: yes.



% .......................... main code below ..............................

% .................. A. Compute spline boundary parameters  ...............

% Define vertices of the curvilinear polygon.
% Notice that first and last sample point are equal.
vertices=[-1 0; -2 -1; -1.5 -2; 0 -1.6; 0 -1; -0.2 -0.5; -0.4 -0.8; ...
    -0.2 -0.9; -0.6 -1.2; -1 0];

XV=vertices(:,1); YV=vertices(:,2);
spline_parms=[spline_order length(XV)];
[Sx,Sy]=compute_spline_boundary(XV,YV,spline_parms,spline_type);




%  ...................... B. Compute reference values  ....................

% 1. Startup.
adeR=30;
[rule_refR,basis_indicesR,V_refR]=cheap_startup(adeR,2); % 2D problem.

% 2. Compute moments (w.r.t. orthonormal basis).
[~,dbox,cmom_orthnR] = spline_chebmom(adeR,Sx,Sy,basis_indicesR);

% 3. Determine rule.
XYR=cheap_rule(rule_refR,V_refR,dbox);
XR=XYR(:,1); YR=XYR(:,2); WR=(rule_refR(:,3)).*V_refR*cmom_orthnR;

% 4. Compute reference integrals.
I=zeros(num_functions,1);
for example=1:num_functions
    f=test_functions(example);
    I(example)=WR'*feval(f,XR,YR);
end



%  .............. C. Compute experiments, varying degree  .................

I_ch=zeros(length(adeV),num_functions);

for ii=1:length(adeV)

    ade=adeV(ii);

    % 1. Startup.
    [rule_refL,basis_indicesL,V_refL]=cheap_startup(ade,2);

    % 2. Moment computation (orthonormal basis w.r.t. scaled tensorial
    % Gauss-Chebyshev weight.
    [~,dbox,cmom_orthnL] = spline_chebmom(ade,Sx,Sy,basis_indicesL);

    % 3. Determine Cheap rule.
    XYL=cheap_rule(rule_refL,V_refL,dbox);
    XL=XYL(:,1); YL=XYL(:,2); WL=(rule_refL(:,3)).*V_refL*cmom_orthnL;

    % 4. Compute integrals.
    IL=zeros(1,num_functions);
    for example=1:num_functions
        f=test_functions(example);
        IL(1,example)=WL'*feval(f,XL,YL);
    end

    % 5. Results storage.
    I_ch(ii,:)=IL;

end



%  .......................... D. Statistics ...............................

fprintf('\n \t .............. relative errors ................ \n ')
fprintf('\n \t |ade |  f1   |  f2   |  f3   |  f4   |  f5  |')
fprintf('\n \t ...............................................')

RE=zeros(length(adeV),num_functions);
for k=1:num_functions
    RE(:,k)=abs(I_ch(:,k)-I(k))/abs(I(k));
end

for k=1:length(adeV)
    fprintf('\n \t  %2.0f  & %1.0e & %1.0e & %1.0e & %1.0e & %1.0e ',...
        adeV(k), RE(k,1),RE(k,2),RE(k,3),RE(k,4),RE(k,5));
end

fprintf('\n \n \t ................ integrands ................... \n \n');
for k=1:num_functions
    switch k
        case 1
            str=' exp(-(x.^2+y.^2))';
        case 2
            str=' (x.^2+y.^2).^(11/2)';
        case 3
            str=' (x.^2+y.^2).^(3/2)';
        case 4
            str=' (0.3+0.1*x-0.2*y).^30';
        case 5
            str=' (1.1+0.5*x-0.2*y).^10';
    end

    strL=strcat('      f',num2str(k),': ',str);
    disp(strL);
end




%  ........................ E. Plot domain/nodes ..........................

fprintf('\n \t .................. plots ...................... \n \n');

disp('      Note: see domain and cubature nodes in figure 1;');
disp('            * green dots : nonnegative weights;');
disp('            * red dots   : negative weights.');
if savefigures == 1
    fprintf('\n \n \t The figure is saved as eps file.');
end
fprintf('\n');

clf;
L=length(Sx);
for ii=1:L
    SxL=Sx(ii); SyL=Sy(ii);
    SxL_breaks=SxL.breaks;
    Nbreaks=length(SxL_breaks);
    for kk=1:Nbreaks-1
        t0=SxL_breaks(kk); t1=SxL_breaks(kk+1);
        N=10^3;
        tt=linspace(t0,t1,N);
        xx=ppval(SxL,tt);
        yy=ppval(SyL,tt);
        plot(xx,yy,'k-','LineWidth',4);
        hold on;
    end
end

for k=1:length(XL)
    x=XL(k); y=YL(k); w=WL(k);
    if w >= 0
        plot(x,y,'go','MarkerSize',4,'MarkerFaceColor','g')
    else
        plot(x,y,'ro','MarkerSize',4,'MarkerFaceColor','r')
    end
end
axis off;
hold off
if savefigures == 1, saveas(gcf,'cub_splines_dom_nodesC.eps','epsc'); end



function f=test_functions(example)

switch example
    case 1
        f=@(x,y) exp(-(x.^2+y.^2));
    case 2
        f=@(x,y) (x.^2+y.^2).^(11/2);
    case 3
        f=@(x,y) (x.^2+y.^2).^(3/2);
    case 4
        f=@(x,y) (0.3+0.1*x-0.2*y).^30;
    case 5
        f=@(x,y) (1.1+0.5*x-0.2*y).^10;
end


