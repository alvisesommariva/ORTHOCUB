
function demo_derivative_ade_3D

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% The purpose of this routine is to test the algorithm proposed in [2] for
% the computation of directional derivatives (up to second order) of
% random polynomials defined in R^3.
%
% For degree "ade" we differentiate random polynomials of degree "ade" of
% the form "(a(1)*x+a(2)*y+a(3)*z+a(4))^ade" with "a" in [0,1]^4 in some 
% Halton points of [-1,1]^3.
%
% For each derivative we compute the maximum relative error made by the
% algorithm on the mesh of "npts".
%
% We perform "ntests" and display for each "ade" these results and its
% logarithmic average.
%--------------------------------------------------------------------------
% Important.
%--------------------------------------------------------------------------
% The routine requires the Matlab-built in function "haltonset".
% In case it is not installed, it is part of the "Statistics and Machine 
% Learning Toolbox".
%--------------------------------------------------------------------------
% External routines
%--------------------------------------------------------------------------
% 1. cheap_startup
% 2. mom_derivative_3D
% 3. cheap_rule
% 4. plot_errors
%
% as well as the procedures potentially called by the routines above.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% [1] "Effective numerical integration on complex shaped elements by
%      discrete signed measures", 2025.
%      by L. Rinaldi, A. Sommariva, M. Vianello.
% [2] "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      m", 2025.
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> tic; demo_derivative_ade_3D; toc
% 
%  	 * investigating degree 2 
%  	 * investigating degree 4 
%  	 * investigating degree 6 
%  	 * investigating degree 8 
%  	 * investigating degree 10
%  	 * investigating degree 12
%  	 * investigating degree 14
%  	 * investigating degree 16
%  	 ............................................ 
% 
%  	 Derivatives are evaluated in   100 pts.
%  	 Number of random polynomials:   100 pts.
%  	 ............................................ 
% 
%  	 See figures in which we describe 
%  	 a) by + the norm 2 of the pointwise errors
%  	    in a cloud of random points divided by the
%  	    norm 2 of the derivatives in that cloud;
%  	 b) by a circle the logarithmic average of
%  	    the quantities above.
%  	 ............................................ 
% 
% >> Elapsed time is 123.626331 seconds
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% Cputime.
%--------------------------------------------------------------------------
% The procedure requires about 123s (in case the figures are not saved).
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 22, 2025
%--------------------------------------------------------------------------

adeV=2:2:16;

% Number of points in [-1,1]^2 in which the derivatives must be computed.
npts=100;

% Number of random polynomials for which the derivatives must be computed.
ntests=100;

% Save figures: 0: no, 1: yes.
savefigures=0;

% ........................... main code below .............................


p=haltonset(3);
pts=p(1:npts,:); x=-1+2*pts(:,1); y=-1+2*pts(:,2); z=-1+2*pts(:,3);

dbox=[-1 -1 -1; 1 1 1]; % Bounding box, containing the points.

card_adeV=length(adeV);
re_x=zeros(ntests,card_adeV);
re_y=zeros(ntests,card_adeV);
re_z=zeros(ntests,card_adeV);
re_xx=zeros(ntests,card_adeV);
re_yy=zeros(ntests,card_adeV);
re_zz=zeros(ntests,card_adeV);
re_xy=zeros(ntests,card_adeV);
re_xz=zeros(ntests,card_adeV);
re_yz=zeros(ntests,card_adeV);

for j=1:card_adeV
    ade=adeV(j);

    fprintf('\n \t * investigating degree %-2.0f',ade);

    for k=1:ntests

        % ...................... random polynomials  ...................

        a(1)=rand(1); a(2)=rand(1); a(3)=rand(1); a(4)=rand(1);

        f=@(x,y,z) (a(1)*x+a(2)*y+a(3)*z+a(4)).^ade;

        % ........................ derivatives  ........................

        FX=@(x,y,z) ade*(a(1)*x+a(2)*y+a(3)*z+a(4)).^(ade-1).*a(1);
        FY=@(x,y,z) ade*(a(1)*x+a(2)*y+a(3)*z+a(4)).^(ade-1).*a(2);
        FZ=@(x,y,z) ade*(a(1)*x+a(2)*y+a(3)*z+a(4)).^(ade-1).*a(3);
        FXX=@(x,y,z) ...
            ade*(ade-1)*(a(1)*x+a(2)*y+a(3)*z+a(4)).^(ade-2).*a(1)^2;
        FYY=@(x,y,z) ...
            ade*(ade-1)*(a(1)*x+a(2)*y+a(3)*z+a(4)).^(ade-2).*a(2)^2;
        FZZ=@(x,y,z) ...
            ade*(ade-1)*(a(1)*x+a(2)*y+a(3)*z+a(4)).^(ade-2).*a(3)^2;
        FXY=@(x,y,z) ...
            ade*(ade-1)*(a(1)*x+a(2)*y+a(3)*z+a(4)).^(ade-2).*a(1)*a(2);
        FXZ=@(x,y,z) ...
            ade*(ade-1)*(a(1)*x+a(2)*y+a(3)*z+a(4)).^(ade-2).*a(1)*a(3);
        FYZ=@(x,y,z) ...
            ade*(ade-1)*(a(1)*x+a(2)*y+a(3)*z+a(4)).^(ade-2).*a(2)*a(3);

        diff_x_ref=FX(x,y,z); % Evaluation of derivatives at "(x,y,z)".
        diff_y_ref=FY(x,y,z);
        diff_z_ref=FZ(x,y,z);
        diff_xx_ref=FXX(x,y,z);
        diff_yy_ref=FYY(x,y,z);
        diff_zz_ref=FZZ(x,y,z);
        diff_xy_ref=FXY(x,y,z);
        diff_xz_ref=FXZ(x,y,z);
        diff_yz_ref=FYZ(x,y,z);


        % ....................... x derivative ............................

        [rule_ref,basis_indices,V_ref]=cheap_startup(ade,3);
        z3=rule_ref(:,4);
        moms_x=mom_derivative_3D(x,y,z,1,0,0,ade,basis_indices,dbox);
        [nodes,w_ch_x]=cheap_rule(rule_ref,V_ref,dbox,moms_x);

        x_ch=nodes(:,1); y_ch=nodes(:,2); z_ch=nodes(:,3);

        fnodes_ch=f(x_ch,y_ch,z_ch);
        diff_x_ch=w_ch_x'*fnodes_ch;


        % ....................... y derivative ............................

        [~,moms0_y]=mom_derivative_3D(x,y,z,0,1,0,ade,basis_indices,dbox);
        w_ch_y=diag(z3)*V_ref*moms0_y;
        diff_y_ch=w_ch_y'*fnodes_ch;


        % ....................... z derivative ............................

        [~,moms0_z]=mom_derivative_3D(x,y,z,0,0,1,ade,basis_indices,dbox);
        w_ch_z=diag(z3)*V_ref*moms0_z;
        diff_z_ch=w_ch_z'*fnodes_ch;



        % ....................... xx derivative ...........................

        [~,moms0_xx]=mom_derivative_3D(x,y,z,2,0,0,ade,basis_indices,dbox);
        w_ch_xx=diag(z3)*V_ref*moms0_xx;
        diff_xx_ch=w_ch_xx'*fnodes_ch;

        % ....................... yy derivative ...........................

        [~,moms0_yy]=mom_derivative_3D(x,y,z,0,2,0,ade,basis_indices,dbox);
        w_ch_yy=diag(z3)*V_ref*moms0_yy;
        diff_yy_ch=w_ch_yy'*fnodes_ch;

        % ....................... zz derivative ...........................

        [~,moms0_zz]=mom_derivative_3D(x,y,z,0,0,2,ade,basis_indices,dbox);
        w_ch_zz=diag(z3)*V_ref*moms0_zz;
        diff_zz_ch=w_ch_zz'*fnodes_ch;

        % ....................... xy derivative ...........................

        [~,moms0_xy]=mom_derivative_3D(x,y,z,1,1,0,ade,basis_indices,dbox);
        w_ch_xy=diag(z3)*V_ref*moms0_xy;
        diff_xy_ch=w_ch_xy'*fnodes_ch;

        % ....................... xz derivative ...........................

        [~,moms0_xz]=mom_derivative_3D(x,y,z,1,0,1,ade,basis_indices,dbox);
        w_ch_xz=diag(z3)*V_ref*moms0_xz;
        diff_xz_ch=w_ch_xz'*fnodes_ch;

        % ....................... xz derivative ...........................

        [~,moms0_yz]=mom_derivative_3D(x,y,z,0,1,1,ade,basis_indices,dbox);
        w_ch_yz=diag(z3)*V_ref*moms0_yz;
        diff_yz_ch=w_ch_yz'*fnodes_ch;

        

        % .......................... Statistics ........................

        ae_xV=diff_x_ref-diff_x_ch;
        re_x(k,j)=norm(ae_xV,2)/norm(diff_x_ref,2);

        ae_yV=diff_y_ref-diff_y_ch;
        re_y(k,j)=norm(ae_yV,2)/norm(diff_y_ref,2);

        ae_zV=diff_z_ref-diff_z_ch;
        re_z(k,j)=norm(ae_zV,2)/norm(diff_z_ref,2);

        ae_xxV=diff_xx_ref-diff_xx_ch;
        re_xx(k,j)=norm(ae_xxV,2)/norm(diff_xx_ref,2);

        ae_yyV=diff_yy_ref-diff_yy_ch;
        re_yy(k,j)=norm(ae_yyV,2)/norm(diff_yy_ref,2);

        ae_zzV=diff_zz_ref-diff_zz_ch;
        re_zz(k,j)=norm(ae_zzV,2)/norm(diff_zz_ref,2);

        ae_xyV=diff_xy_ref-diff_xy_ch;
        re_xy(k,j)=norm(ae_xyV,2)/norm(diff_xy_ref,2);

        ae_xzV=diff_xz_ref-diff_xz_ch;
        re_xz(k,j)=norm(ae_xzV,2)/norm(diff_xz_ref,2);

        ae_yzV=diff_yz_ref-diff_yz_ch;
        re_yz(k,j)=norm(ae_yzV,2)/norm(diff_yz_ref,2);

    end
end




% .......................... plot results  ................................

fprintf('\n \t ............................................ \n');
fprintf('\n \t Derivatives are evaluated in %5.0f pts.',npts);
fprintf('\n \t Number of random polynomials: %5.0f pts.',ntests);
fprintf('\n \t ............................................ \n');
fprintf('\n \t See figures in which we describe ');
fprintf('\n \t a) by + the norm 2 of the pointwise errors');
fprintf('\n \t    in a cloud of random points divided by the');
fprintf('\n \t    norm 2 of the derivatives in that cloud;');
fprintf('\n \t b) by a circle the logarithmic average of');
fprintf('\n \t    the quantities above.');
if savefigures == 1
    fprintf('\n \n \t All the figures are saved in eps files.');
end
fprintf('\n \t ............................................ \n \n');



figure(1)
for ii=1:card_adeV
    reL=re_x(:,ii);
    iok=reL > 0;
    log_reL=10^(mean(log10(reL(iok))));
    plot_errors(ii,adeV,reL,log_reL);
    hold on;
end
title('x-derivative')
hold off;
if savefigures == 1, saveas(gcf,'diff_3D_x.eps','epsc'); end




figure(2)
for ii=1:card_adeV
    reL=re_y(:,ii);
    iok=reL > 0;
    log_reL=10^(mean(log10(reL(iok))));
    plot_errors(ii,adeV,reL,log_reL);
    hold on;
end
title('y-derivative')
if savefigures == 1, saveas(gcf,'diff_3D_y.eps','epsc'); end
hold off;



figure(3)
for ii=1:card_adeV
    reL=re_xx(:,ii);
    iok=reL > 0;
    log_reL=10^(mean(log10(reL(iok))));
    plot_errors(ii,adeV,reL,log_reL);
    hold on;
end
title('xx-derivative')
if savefigures == 1, saveas(gcf,'diff_3D_xx.eps','epsc'); end
hold off;



figure(4)
for ii=1:card_adeV
    reL=re_yy(:,ii);
    iok=reL > 0;
    log_reL=10^(mean(log10(reL(iok))));
    plot_errors(ii,adeV,reL,log_reL);
    hold on;
end
title('yy-derivative')
if savefigures == 1, saveas(gcf,'diff_3D_yy.eps','epsc'); end
hold off;



figure(5)
for ii=1:card_adeV
    reL=re_zz(:,ii);
    iok=reL > 0;
    log_reL=10^(mean(log10(reL(iok))));
    plot_errors(ii,adeV,reL,log_reL);
    hold on;
end
title('zz-derivative')
hold off;
if savefigures == 1, saveas(gcf,'diff_3D_zz.eps','epsc'); end



figure(6)
for ii=1:card_adeV
    reL=re_xy(:,ii);
    iok=reL > 0;
    log_reL=10^(mean(log10(reL(iok))));
    plot_errors(ii,adeV,reL,log_reL);
    hold on;
end
title('xy-derivative')
hold off;
if savefigures == 1, saveas(gcf,'diff_3D_xy.eps','epsc'); end



figure(7)
for ii=1:card_adeV
    reL=re_xz(:,ii);
    iok=reL > 0;
    log_reL=10^(mean(log10(reL(iok))));
    plot_errors(ii,adeV,reL,log_reL);
    hold on;
end
title('xz-derivative')
hold off;
if savefigures == 1, saveas(gcf,'diff_3D_xz.eps','epsc'); end



figure(8)
for ii=1:card_adeV
    reL=re_yz(:,ii);
    iok=reL > 0;
    log_reL=10^(mean(log10(reL(iok))));
    plot_errors(ii,adeV,reL,log_reL);
    hold on;
end
title('yz-derivative')
hold off;
if savefigures == 1, saveas(gcf,'diff_3D_yz.eps','epsc'); end








%==========================================================================
% plot_errors
%==========================================================================

function plot_errors(ii,adeV,reV,log_re)

%--------------------------------------------------------------------------
% Object
%--------------------------------------------------------------------------
% Given a vector of algebraic degree of precisions "adeV", it selects the
% algebraic degree of precision "ade=adeV(ii)" and plots all the
% experimental relative errors "reV" with a coloured cross and a circle
% describing its logarithmic average "log_re"
%--------------------------------------------------------------------------

n=adeV(ii);

xmin=min(adeV);
xmax=max(adeV);
xlim([xmin xmax]);
ylim([10^(-20) 10^(-2)]);

grid on;

% Get handle to current axes.
ax = gca;
ax.XAxis.FontSize = 9;
ax.YAxis.FontSize = 9;
set(gca,'XTickLabel',{adeV})
C=colororder("glow12");

if ii <= 12
    plotstr='+';
    semilogy(n*ones(size(reV)),reV,plotstr,'color',C(ii,:)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',20,'MarkerEdgeColor','k');
else
    plotstr='+';
    semilogy(n*ones(size(reV)),reV,plotstr,'color',rand(1,3)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',20,'MarkerEdgeColor','k');
end
