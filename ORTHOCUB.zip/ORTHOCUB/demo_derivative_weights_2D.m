
function demo_derivative_weights_2D

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% The purpose of this routine is to compute at any degree "ade",
%
% 1. for any point of a pointset in [-1,1]^2 we compute the sum of the 
%    absolute values of weights, used to determine directional derivatives;
%
% 2. we determine for some directional derivatives the maximum of the 
%    quantity above;
%
% 3. we plot these quantities.
%--------------------------------------------------------------------------
% Important.
%--------------------------------------------------------------------------
% The routine requires the Matlab-built in function "haltonset".
% In case it is not installed, it is part of the "Statistics and Machine
% Learning Toolbox".
%--------------------------------------------------------------------------
% External routines
%--------------------------------------------------------------------------
% 1. cheap_startup2
% 2. mom_derivative_2D
% as well as the procedures potentially called by the routines above.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% [1]  "ORTHOCUB: integral and  differential cubature rules by orthogonal
%      moments", 2025,
%      by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> tic;demo_derivative_weights_2D;toc
%
%  	 ade |    x    |    y     |    xx   |    xy   |    yy   |
% 	 ........................................................
% 	  1  & 1.0e+00 &  1.0e+00 & 0.0e+00 & 0.0e+00 & 0.0e+00 &
% 	  2  & 5.3e+00 &  5.3e+00 & 5.3e+00 & 1.8e+00 & 5.3e+00 &
% 	  3  & 1.3e+01 &  1.3e+01 & 3.2e+01 & 1.1e+01 & 3.2e+01 &
% 	  4  & 2.7e+01 &  2.7e+01 & 1.1e+02 & 3.8e+01 & 1.1e+02 &
% 	  5  & 4.5e+01 &  4.5e+01 & 3.0e+02 & 1.0e+02 & 3.0e+02 &
% 	  6  & 7.0e+01 &  7.0e+01 & 6.6e+02 & 2.0e+02 & 6.6e+02 &
% 	  7  & 1.0e+02 &  1.0e+02 & 1.3e+03 & 4.2e+02 & 1.3e+03 &
% 	  8  & 1.4e+02 &  1.4e+02 & 2.4e+03 & 6.5e+02 & 2.4e+03 &
% 	  9  & 1.9e+02 &  1.9e+02 & 4.0e+03 & 1.2e+03 & 4.0e+03 &
% 	 10  & 2.4e+02 &  2.4e+02 & 6.3e+03 & 1.6e+03 & 6.3e+03 &
% 	 11  & 3.1e+02 &  3.1e+02 & 9.6e+03 & 2.8e+03 & 9.6e+03 &
% 	 12  & 3.7e+02 &  3.7e+02 & 1.4e+04 & 3.1e+03 & 1.4e+04 &
% 	 13  & 4.6e+02 &  4.6e+02 & 2.0e+04 & 5.8e+03 & 2.0e+04 &
% 	 14  & 5.4e+02 &  5.4e+02 & 2.8e+04 & 6.0e+03 & 2.8e+04 &
% 	 15  & 6.5e+02 &  6.5e+02 & 3.8e+04 & 1.1e+04 & 3.8e+04 &
% 	 16  & 7.4e+02 &  7.4e+02 & 5.0e+04 & 1.0e+04 & 5.0e+04 &
%
%  	 ............................................
%
%  	 Derivatives are evaluated in 10000 pts.
%  	 ............................................
%
%  	 See figure in which we describe at any degree
%  	 the maximum sum of absolute weights.
%  	 ............................................
%
% Elapsed time is 1.340522 seconds.
%
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% Cputime.
%--------------------------------------------------------------------------
% The procedure requires about 1.34s (in case the figures are not saved).
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 21, 2025
%--------------------------------------------------------------------------

adeV=1:1:16;

% Number of points in [-1,1]^2 in which the derivatives must be computed.
npts=10000;

% Save figures: 0: no, 1: yes.
savefigures=0;

% ........................... main code below .............................

p=haltonset(2);
pts=p(1:npts,:); x=-1+2*pts(:,1); y=-1+2*pts(:,2);

dbox=[-1 -1; 1 1]; % Bounding box, containing the points.

card_adeV=length(adeV);
sum_absw_x=zeros(1,card_adeV);
sum_absw_y=zeros(1,card_adeV);
sum_absw_xx=zeros(1,card_adeV);
sum_absw_xy=zeros(1,card_adeV);
sum_absw_yy=zeros(1,card_adeV);

for j=1:card_adeV
    ade=adeV(j);

    % .......................... x derivative ......................

    [rule_ref,duples,V_ref]=cheap_startup2(ade,2);
    z=rule_ref(:,3);

    [~,moms0_x]=mom_derivative_2D(x,y,1,0,ade,duples,dbox);
    w_ch_x=diag(z)*V_ref*moms0_x;

    sum_absw_x(j)=max(sum(abs(w_ch_x),1));

    % .......................... y derivative ......................

    [~,moms0_y]=mom_derivative_2D(x,y,0,1,ade,duples,dbox);
    w_ch_y=diag(z)*V_ref*moms0_y;
    sum_absw_y(j)=max(sum(abs(w_ch_y),1));

    % .......................... xx derivative .....................

    [~,moms0_xx]=mom_derivative_2D(x,y,2,0,ade,duples,dbox);
    w_ch_xx=diag(z)*V_ref*moms0_xx;
    sum_absw_xx(j)=max(sum(abs(w_ch_xx),1));

    % .......................... yy derivative .....................

    [~,moms0_yy]=mom_derivative_2D(x,y,0,2,ade,duples,dbox);
    w_ch_yy=diag(z)*V_ref*moms0_yy;
    sum_absw_yy(j)=max(sum(abs(w_ch_yy),1));

    % .......................... xy derivative .....................

    [~,moms0_xy]=mom_derivative_2D(x,y,1,1,ade,duples,dbox);
    w_ch_xy=diag(z)*V_ref*moms0_xy;
    sum_absw_xy(j)=max(sum(abs(w_ch_xy),1));



end




% .......................... statistics .........................
fprintf('\n \t ')
fprintf('ade |    x    |    y     |    xx   |    xy   |    yy   |\n');
fprintf('\t ........................................................\n');
for j=1:card_adeV
    ade=adeV(j);
    fprintf('\t');
    fprintf('%2.0f  & %1.1e &  %1.1e & %1.1e & %1.1e & %1.1e & %1.1e',...
        ade,sum_absw_x(j),sum_absw_y(j),sum_absw_xx(j),sum_absw_xy(j),...
        sum_absw_yy(j));
    fprintf('\n');
end




% .......................... plot results  ................................

fprintf('\n \t ............................................ \n');
fprintf('\n \t Derivatives are evaluated in %5.0f pts.',npts);
fprintf('\n \t ............................................ \n');
fprintf('\n \t See figure in which we describe at any degree');
fprintf('\n \t the maximum sum of absolute weights values.');
if savefigures == 1
    fprintf('\n \n \t The figure is saved as eps file.');
end
fprintf('\n \t ............................................ \n \n');

clf;
figure(1)
lw=1; % linewidth
ms=6; % markersize

for ii=1:card_adeV
    semilogy(adeV,sum_absw_x,'bo-','MarkerSize',ms,'LineWidth',lw);
    hold on;
    semilogy(adeV,sum_absw_xx,'co-','MarkerSize',ms,'LineWidth',lw);
    semilogy(adeV,sum_absw_xy,'rd-','MarkerSize',ms,'LineWidth',lw);
end
grid on;
legend('x, y','xx, yy','xy');
legend('Location','northwest')
hold off;
if savefigures == 1, saveas(gcf,'diff_weights_2D.eps','epsc'); end







